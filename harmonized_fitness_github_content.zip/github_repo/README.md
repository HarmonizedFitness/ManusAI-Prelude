# Harmonized Fitness - 14-Day "Master the Little Things" Prelude

This repository contains the Next.js implementation of the Harmonized Fitness 14-Day "Master the Little Things" Prelude program for Lovable.dev.

## Project Structure

- `/pages` - Next.js pages including the landing page and daily content pages
- `/components` - Reusable React components
- `/styles` - CSS and styled-components
- `/public` - Static assets like images and PDFs
- `/lib` - Utility functions and API integrations

## Features

- Landing page with program overview
- 14 days of structured content
- B.R.E.A.T.H.E. Code implementation
- Chakra awareness integration
- Dr. U chatbot integration (via OpenAI)
- User authentication (via Supabase)
- Email sequence templates
- Downloadable resources

## Getting Started

1. Clone this repository
2. Install dependencies with `npm install`
3. Run the development server with `npm run dev`
4. Open [http://localhost:3000](http://localhost:3000) in your browser

## Technology Stack

- Next.js
- React
- Styled Components
- Supabase (for authentication and database)
- OpenAI (for Dr. U chatbot)

## Content Structure

The 14-Day Prelude program follows this structure:

1. Awakening Awareness
2. Breath & Presence
3. Body Intelligence
4. Emotional Awareness
5. Mental Patterns
6. Stress Resilience
7. Habit Formation
8. Energy Cultivation
9. Intuitive Nutrition
10. Rest & Recovery
11. Communication & Expression
12. Mindfulness & Presence
13. Intuition & Inner Guidance
14. Integration & Continuation

Each day includes morning rituals, physical practices, integration exercises, and evening check-ins.

## Deployment

This project is configured for deployment on Vercel or Netlify.
