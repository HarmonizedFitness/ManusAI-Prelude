import { useState } from 'react';
import styled from 'styled-components';

const DayLayout = ({ day, title, children }) => {
  const [activeTab, setActiveTab] = useState('morning');

  return (
    <Container>
      <Header>
        <BackLink href="/">← Back to Home</BackLink>
        <DayInfo>
          <DayNumber>Day {day}</DayNumber>
          <DayTitle>{title}</DayTitle>
        </DayInfo>
      </Header>

      <Main>
        <TabsContainer>
          <Tab 
            active={activeTab === 'morning'} 
            onClick={() => setActiveTab('morning')}
          >
            Morning Ritual
          </Tab>
          <Tab 
            active={activeTab === 'physical'} 
            onClick={() => setActiveTab('physical')}
          >
            Physical Practice
          </Tab>
          <Tab 
            active={activeTab === 'integration'} 
            onClick={() => setActiveTab('integration')}
          >
            Integration Practice
          </Tab>
          <Tab 
            active={activeTab === 'evening'} 
            onClick={() => setActiveTab('evening')}
          >
            Evening Check-in
          </Tab>
          <Tab 
            active={activeTab === 'resources'} 
            onClick={() => setActiveTab('resources')}
          >
            Resources
          </Tab>
        </TabsContainer>

        <ContentContainer>
          {children}
        </ContentContainer>
      </Main>

      <ProgressContainer>
        <ProgressTitle>Your 14-Day Journey</ProgressTitle>
        <ProgressBar>
          {[...Array(14)].map((_, index) => (
            <ProgressDot 
              key={index} 
              active={index + 1 <= day}
              current={index + 1 === day}
              href={`/day${index + 1}`}
            />
          ))}
        </ProgressBar>
        <DayNavigation>
          {day > 1 && (
            <NavButton href={`/day${day - 1}`}>
              ← Previous Day
            </NavButton>
          )}
          {day < 14 && (
            <NavButton href={`/day${day + 1}`}>
              Next Day →
            </NavButton>
          )}
        </DayNavigation>
      </ProgressContainer>

      <DrUContainer>
        <DrUButton>
          Ask Dr. U
        </DrUButton>
      </DrUContainer>
    </Container>
  );
};

// Styled Components
const Container = styled.div`
  background-color: #2A2A2A;
  color: #FFFFFF;
  font-family: 'Georgia', serif;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
`;

const Header = styled.header`
  padding: 2rem;
  display: flex;
  flex-direction: column;
  gap: 1rem;
`;

const BackLink = styled.a`
  color: #D35400;
  text-decoration: none;
  font-size: 1rem;
  
  &:hover {
    text-decoration: underline;
  }
`;

const DayInfo = styled.div`
  text-align: center;
`;

const DayNumber = styled.div`
  font-size: 1.25rem;
  color: #D35400;
`;

const DayTitle = styled.h1`
  font-size: 2.5rem;
  margin: 0.5rem 0;
`;

const Main = styled.main`
  flex: 1;
  padding: 0 2rem 2rem;
  max-width: 1200px;
  margin: 0 auto;
  width: 100%;
`;

const TabsContainer = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
  margin-bottom: 2rem;
  
  @media (max-width: 768px) {
    flex-direction: column;
  }
`;

const Tab = styled.button`
  padding: 1rem;
  background-color: ${props => props.active ? '#D35400' : '#333333'};
  color: #FFFFFF;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  flex: 1;
  font-family: 'Georgia', serif;
  font-size: 1rem;
  
  &:hover {
    background-color: ${props => props.active ? '#D35400' : '#444444'};
  }
`;

const ContentContainer = styled.div`
  background-color: #333333;
  padding: 2rem;
  border-radius: 8px;
`;

const ProgressContainer = styled.div`
  padding: 2rem;
  background-color: #222222;
`;

const ProgressTitle = styled.h2`
  text-align: center;
  font-size: 1.5rem;
  margin-bottom: 1rem;
`;

const ProgressBar = styled.div`
  display: flex;
  justify-content: space-between;
  max-width: 800px;
  margin: 0 auto 2rem;
`;

const ProgressDot = styled.a`
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background-color: ${props => props.active ? '#D35400' : '#444444'};
  border: ${props => props.current ? '3px solid #FFFFFF' : 'none'};
  cursor: pointer;
  text-decoration: none;
`;

const DayNavigation = styled.div`
  display: flex;
  justify-content: space-between;
  max-width: 800px;
  margin: 0 auto;
`;

const NavButton = styled.a`
  padding: 0.75rem 1.5rem;
  background-color: #333333;
  color: #FFFFFF;
  text-decoration: none;
  border-radius: 4px;
  
  &:hover {
    background-color: #D35400;
  }
`;

const DrUContainer = styled.div`
  position: fixed;
  bottom: 2rem;
  right: 2rem;
`;

const DrUButton = styled.button`
  background-color: #D35400;
  color: #FFFFFF;
  border: none;
  border-radius: 50%;
  width: 60px;
  height: 60px;
  font-size: 0.75rem;
  cursor: pointer;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
  
  &:hover {
    background-color: #E67E22;
  }
`;

export default DayLayout;
