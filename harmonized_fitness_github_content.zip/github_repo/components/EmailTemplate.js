import styled from 'styled-components';

const EmailTemplate = ({ children }) => {
  return (
    <Container>
      {children}
    </Container>
  );
};

// Styled Components
const Container = styled.div`
  font-family: 'Georgia', serif;
  max-width: 600px;
  margin: 0 auto;
  padding: 20px;
  background-color: #2A2A2A;
  color: #FFFFFF;
  border-radius: 8px;
`;

export default EmailTemplate;
