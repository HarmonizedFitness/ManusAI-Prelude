import styled from 'styled-components';

const PDFTemplate = ({ title, children }) => {
  return (
    <Container>
      <Header>
        <Logo>Harmonized Fitness</Logo>
        <Title>{title}</Title>
      </Header>
      
      <Content>
        {children}
      </Content>
      
      <Footer>
        <FooterText>© 2025 Harmonized Fitness. All rights reserved.</FooterText>
        <FooterText>www.harmonizedfitness.com</FooterText>
      </Footer>
    </Container>
  );
};

// Styled Components
const Container = styled.div`
  font-family: 'Georgia', serif;
  max-width: 800px;
  margin: 0 auto;
  padding: 40px;
  background-color: #2A2A2A;
  color: #FFFFFF;
  border-radius: 8px;
`;

const Header = styled.div`
  text-align: center;
  margin-bottom: 40px;
  padding-bottom: 20px;
  border-bottom: 2px solid #D35400;
`;

const Logo = styled.div`
  font-size: 24px;
  font-weight: bold;
  color: #D35400;
  margin-bottom: 10px;
`;

const Title = styled.h1`
  font-size: 28px;
  color: #FFFFFF;
`;

const Content = styled.div`
  margin-bottom: 40px;
`;

const Footer = styled.div`
  text-align: center;
  padding-top: 20px;
  border-top: 2px solid #D35400;
  font-size: 14px;
`;

const FooterText = styled.p`
  margin: 5px 0;
`;

export default PDFTemplate;
