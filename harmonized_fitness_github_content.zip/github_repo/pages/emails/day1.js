import styled from 'styled-components';
import EmailTemplate from '../components/EmailTemplate';

const Day1Email = () => {
  return (
    <EmailTemplate>
      <EmailHeader>
        <Logo>Harmonized Fitness</Logo>
      </EmailHeader>
      
      <EmailContent>
        <Heading>Day 1: Awakening Awareness</Heading>
        
        <Paragraph>
          Dear [First Name],
        </Paragraph>
        
        <Paragraph>
          Today marks the beginning of your 14-day journey! Day 1 focuses on <strong>Awakening Awareness</strong>—the foundation of all transformation. When we become truly aware of our current state, we create the possibility for change.
        </Paragraph>
        
        <DailyOverview>
          <OverviewTitle>Today's Focus</OverviewTitle>
          <OverviewContent>
            <OverviewItem>
              <ItemTitle>Morning Ritual</ItemTitle>
              <ItemDescription>Intention setting and body scan meditation to establish baseline awareness.</ItemDescription>
            </OverviewItem>
            
            <OverviewItem>
              <ItemTitle>Physical Practice</ItemTitle>
              <ItemDescription>Movement assessment to understand your current patterns and establish a foundation.</ItemDescription>
            </OverviewItem>
            
            <OverviewItem>
              <ItemTitle>Integration Practice</ItemTitle>
              <ItemDescription>Mindful moment exercise to bring awareness to everyday activities.</ItemDescription>
            </OverviewItem>
            
            <OverviewItem>
              <ItemTitle>Evening Check-in</ItemTitle>
              <ItemDescription>Reflection, gratitude practice, and preparation for tomorrow's micro-habit.</ItemDescription>
            </OverviewItem>
          </OverviewContent>
        </DailyOverview>
        
        <Quote>
          "Awareness is the greatest agent for change." - Eckhart Tolle
        </Quote>
        
        <Paragraph>
          <strong>Key Insight:</strong> Today's practices demonstrate how awareness transforms even the simplest activities into opportunities for presence and growth—the essence of "mastering the little things."
        </Paragraph>
        
        <Paragraph>
          Remember, there's no need to perfect these practices. Simply showing up and bringing your attention to each moment is enough to begin the transformation process.
        </Paragraph>
        
        <CTAButton href="https://harmonizedfitness.com/day1">
          Access Today's Practices
        </CTAButton>
        
        <ResourceSection>
          <ResourceTitle>Today's Resources</ResourceTitle>
          <ResourceList>
            <ResourceItem>
              <ResourceLink href="https://harmonizedfitness.com/pdfs/day1_practice_worksheet.pdf">
                Day 1 Practice Worksheet
              </ResourceLink>
            </ResourceItem>
            <ResourceItem>
              <ResourceLink href="https://harmonizedfitness.com/pdfs/awareness_techniques.pdf">
                Awareness Techniques Guide
              </ResourceLink>
            </ResourceItem>
          </ResourceList>
        </ResourceSection>
        
        <Paragraph>
          If you have any questions, Dr. U is available to assist you through the app or website.
        </Paragraph>
        
        <Paragraph>
          Here's to your first day of transformation,
        </Paragraph>
        
        <Signature>
          The Harmonized Fitness Team
        </Signature>
      </EmailContent>
      
      <EmailFooter>
        <FooterLinks>
          <a href="#">Unsubscribe</a> | <a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a>
        </FooterLinks>
        <FooterText>
          © 2025 Harmonized Fitness. All rights reserved.<br />
          123 Wellness Way, Austin, TX 78701
        </FooterText>
      </EmailFooter>
    </EmailTemplate>
  );
};

// Styled Components
const EmailHeader = styled.div`
  text-align: center;
  margin-bottom: 30px;
`;

const Logo = styled.div`
  font-size: 24px;
  font-weight: bold;
  color: #D35400;
`;

const EmailContent = styled.div`
  padding: 20px;
  background-color: #333333;
  border-radius: 8px;
`;

const Heading = styled.h1`
  font-size: 24px;
  color: #D35400;
  margin-bottom: 20px;
  text-align: center;
`;

const Paragraph = styled.p`
  margin-bottom: 20px;
  line-height: 1.6;
`;

const DailyOverview = styled.div`
  background-color: #2A2A2A;
  padding: 20px;
  border-radius: 8px;
  margin: 30px 0;
`;

const OverviewTitle = styled.h2`
  font-size: 20px;
  color: #D35400;
  margin-bottom: 15px;
  text-align: center;
`;

const OverviewContent = styled.div`
  display: grid;
  grid-template-columns: 1fr;
  gap: 15px;
`;

const OverviewItem = styled.div`
  padding-bottom: 15px;
  border-bottom: 1px solid #444444;
  
  &:last-child {
    border-bottom: none;
    padding-bottom: 0;
  }
`;

const ItemTitle = styled.h3`
  font-size: 18px;
  color: #FFFFFF;
  margin-bottom: 5px;
`;

const ItemDescription = styled.p`
  margin: 0;
  color: #CCCCCC;
`;

const Quote = styled.blockquote`
  font-style: italic;
  border-left: 3px solid #D35400;
  padding-left: 15px;
  margin: 30px 0;
  color: #E67E22;
`;

const CTAButton = styled.a`
  display: block;
  background-color: #D35400;
  color: #FFFFFF;
  text-align: center;
  padding: 15px;
  border-radius: 4px;
  text-decoration: none;
  font-weight: bold;
  margin: 30px 0;
  
  &:hover {
    background-color: #E67E22;
  }
`;

const ResourceSection = styled.div`
  background-color: #2A2A2A;
  padding: 20px;
  border-radius: 8px;
  margin: 30px 0;
`;

const ResourceTitle = styled.h3`
  font-size: 18px;
  color: #D35400;
  margin-bottom: 15px;
`;

const ResourceList = styled.ul`
  list-style: none;
  padding: 0;
  margin: 0;
`;

const ResourceItem = styled.li`
  margin-bottom: 10px;
  
  &:last-child {
    margin-bottom: 0;
  }
`;

const ResourceLink = styled.a`
  color: #FFFFFF;
  text-decoration: none;
  display: inline-block;
  padding: 8px 0;
  
  &:hover {
    color: #D35400;
  }
  
  &:before {
    content: "→ ";
    color: #D35400;
  }
`;

const Signature = styled.p`
  font-style: italic;
  margin-top: 30px;
`;

const EmailFooter = styled.div`
  margin-top: 30px;
  text-align: center;
  font-size: 12px;
  color: #999999;
`;

const FooterLinks = styled.div`
  margin-bottom: 10px;
  
  a {
    color: #999999;
    text-decoration: none;
    
    &:hover {
      text-decoration: underline;
    }
  }
`;

const FooterText = styled.div`
  line-height: 1.5;
`;

export default Day1Email;
