import styled from 'styled-components';
import EmailTemplate from '../components/EmailTemplate';

const WelcomeEmail = () => {
  return (
    <EmailTemplate>
      <EmailHeader>
        <Logo>Harmonized Fitness</Logo>
      </EmailHeader>
      
      <EmailContent>
        <Heading>Welcome to Your 14-Day "Master the Little Things" Prelude</Heading>
        
        <Paragraph>
          Dear [First Name],
        </Paragraph>
        
        <Paragraph>
          Welcome to the beginning of your transformation journey! I'm thrilled that you've chosen to join our 14-Day "Master the Little Things" Prelude program. This experience is designed to help you develop awareness, establish powerful habits, and create a foundation for lasting change.
        </Paragraph>
        
        <Paragraph>
          <strong>Your journey begins tomorrow.</strong> Here's what you need to know:
        </Paragraph>
        
        <InfoBox>
          <InfoItem>
            <InfoTitle>Program Access</InfoTitle>
            <InfoText>You can access your program through our app or website using the login credentials you created during registration.</InfoText>
          </InfoItem>
          
          <InfoItem>
            <InfoTitle>Daily Structure</InfoTitle>
            <InfoText>Each day includes a morning ritual, physical practice, integration exercise, and evening check-in—all designed to take 30-45 minutes total.</InfoText>
          </InfoItem>
          
          <InfoItem>
            <InfoTitle>Dr. U Support</InfoTitle>
            <InfoText>Your AI coach, Dr. U, is available 24/7 to answer questions, provide guidance, and support your journey.</InfoText>
          </InfoItem>
        </InfoBox>
        
        <Paragraph>
          <strong>What makes this program different?</strong> Instead of focusing solely on physical training, we integrate mind, body, and spirit for complete transformation. You'll learn the B.R.E.A.T.H.E. Code, explore chakra awareness, and develop habits that create lasting change.
        </Paragraph>
        
        <Paragraph>
          Remember, transformation happens through small, consistent actions—mastering the little things. I'm excited to guide you through this journey.
        </Paragraph>
        
        <CTAButton href="https://harmonizedfitness.com/login">
          Access Your Program
        </CTAButton>
        
        <Paragraph>
          If you have any questions before we begin, simply reply to this email or reach out to Dr. U through the app.
        </Paragraph>
        
        <Paragraph>
          Here's to your transformation,
        </Paragraph>
        
        <Signature>
          Kyle Zagrodzky<br />
          Founder, Harmonized Fitness
        </Signature>
      </EmailContent>
      
      <EmailFooter>
        <FooterLinks>
          <a href="#">Unsubscribe</a> | <a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a>
        </FooterLinks>
        <FooterText>
          © 2025 Harmonized Fitness. All rights reserved.<br />
          123 Wellness Way, Austin, TX 78701
        </FooterText>
      </EmailFooter>
    </EmailTemplate>
  );
};

// Styled Components
const EmailHeader = styled.div`
  text-align: center;
  margin-bottom: 30px;
`;

const Logo = styled.div`
  font-size: 24px;
  font-weight: bold;
  color: #D35400;
`;

const EmailContent = styled.div`
  padding: 20px;
  background-color: #333333;
  border-radius: 8px;
`;

const Heading = styled.h1`
  font-size: 24px;
  color: #D35400;
  margin-bottom: 20px;
  text-align: center;
`;

const Paragraph = styled.p`
  margin-bottom: 20px;
  line-height: 1.6;
`;

const InfoBox = styled.div`
  background-color: #2A2A2A;
  padding: 20px;
  border-radius: 8px;
  margin: 30px 0;
`;

const InfoItem = styled.div`
  margin-bottom: 15px;
  
  &:last-child {
    margin-bottom: 0;
  }
`;

const InfoTitle = styled.h3`
  font-size: 18px;
  color: #D35400;
  margin-bottom: 5px;
`;

const InfoText = styled.p`
  margin: 0;
`;

const CTAButton = styled.a`
  display: block;
  background-color: #D35400;
  color: #FFFFFF;
  text-align: center;
  padding: 15px;
  border-radius: 4px;
  text-decoration: none;
  font-weight: bold;
  margin: 30px 0;
  
  &:hover {
    background-color: #E67E22;
  }
`;

const Signature = styled.p`
  font-style: italic;
  margin-top: 30px;
`;

const EmailFooter = styled.div`
  margin-top: 30px;
  text-align: center;
  font-size: 12px;
  color: #999999;
`;

const FooterLinks = styled.div`
  margin-bottom: 10px;
  
  a {
    color: #999999;
    text-decoration: none;
    
    &:hover {
      text-decoration: underline;
    }
  }
`;

const FooterText = styled.div`
  line-height: 1.5;
`;

export default WelcomeEmail;
