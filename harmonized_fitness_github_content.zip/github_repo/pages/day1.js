import { useState } from 'react';
import Head from 'next/head';
import DayLayout from '../components/DayLayout';
import styled from 'styled-components';

const Day1 = () => {
  const [activeTab, setActiveTab] = useState('morning');

  return (
    <>
      <Head>
        <title>Day 1: Awakening Awareness | Harmonized Fitness</title>
        <meta name="description" content="Begin your 14-day journey with foundational awareness practices that connect mind, body, and spirit." />
      </Head>

      <DayLayout day={1} title="Awakening Awareness">
        {activeTab === 'morning' && (
          <MorningSection>
            <h2>Morning Ritual</h2>
            <p>Welcome to Day 1 of your 14-day journey! Today we begin by awakening awareness—the foundation of all transformation. When we become truly aware of our current state, we create the possibility for change.</p>
            
            <h3>Intention Setting (5 minutes)</h3>
            <p>Find a quiet space where you won't be disturbed. Sit comfortably with your spine straight but not rigid. Close your eyes and take three deep breaths, feeling your body settle into the present moment.</p>
            <p>Ask yourself: "What is my intention for this 14-day journey?" Listen for the answer that arises naturally. It might be related to physical wellbeing, mental clarity, emotional balance, or spiritual connection.</p>
            <p>Once you've identified your intention, state it silently or aloud in a simple, positive phrase: "My intention is to..."</p>
            
            <h3>Body Scan (10 minutes)</h3>
            <p>Remaining in your seated position, bring your awareness to your body. We'll practice a simple body scan to establish baseline awareness.</p>
            <p>Starting at the crown of your head, slowly move your attention downward, noticing sensations without judgment. Observe areas of tension, comfort, warmth, coolness, heaviness, or lightness.</p>
            <p>When you notice tension, breathe into that area and imagine releasing it with your exhale. Continue down through your face, neck, shoulders, arms, torso, hips, legs, and feet.</p>
            <p>This practice establishes the mind-body connection that we'll build upon throughout the program.</p>
            
            <Quote>"Awareness is the greatest agent for change." - Eckhart Tolle</Quote>
          </MorningSection>
        )}

        {activeTab === 'physical' && (
          <PhysicalSection>
            <h2>Physical Practice</h2>
            <p>Today's physical practice focuses on foundational movement patterns and body awareness. These movements will help you establish a baseline understanding of how your body moves and feels.</p>
            
            <h3>Movement Assessment (15 minutes)</h3>
            <p>Before beginning any fitness program, it's important to understand your current movement patterns. This simple assessment will help you identify areas for improvement.</p>
            
            <h4>1. Standing Posture Check</h4>
            <p>Stand naturally in front of a mirror or have someone take a photo of you from the front and side.</p>
            <p>Notice:</p>
            <ul>
              <li>Is your weight evenly distributed between both feet?</li>
              <li>Are your shoulders level or is one higher than the other?</li>
              <li>Is your head centered over your shoulders or jutting forward?</li>
              <li>Are your knees aligned with your ankles or do they cave inward/outward?</li>
            </ul>
            <p>Simply observe without judgment. Awareness is the first step toward improvement.</p>
            
            <h4>2. Foundational Movements</h4>
            <p>Perform each movement slowly, focusing on form and how your body feels:</p>
            
            <MovementItem>
              <h5>Squat (5 reps)</h5>
              <p>Stand with feet shoulder-width apart, toes slightly turned out. Lower your body as if sitting in a chair, keeping your chest up and knees tracking over toes. Only go as deep as is comfortable.</p>
              <p><strong>Things to think about:</strong> Where do you feel tension? Is it easy to keep your heels down? Does your lower back remain neutral?</p>
            </MovementItem>
            
            <MovementItem>
              <h5>Push-up or Wall Push (5 reps)</h5>
              <p>For standard push-ups: Begin in plank position with hands slightly wider than shoulders. Lower your body by bending your elbows, keeping your body in a straight line.</p>
              <p>For wall push: Stand facing a wall, place hands on the wall at shoulder height, and perform the pushing motion.</p>
              <p><strong>Things to think about:</strong> Can you maintain a straight line from head to heels? Do you feel balanced between both arms?</p>
            </MovementItem>
            
            <MovementItem>
              <h5>Hip Hinge (5 reps)</h5>
              <p>Stand with feet hip-width apart. Keeping your back flat, push your hips backward as if closing a door with your buttocks. Allow a slight bend in the knees.</p>
              <p><strong>Things to think about:</strong> Can you feel the movement coming from your hips rather than your lower back? Do your hamstrings engage?</p>
            </MovementItem>
            
            <Quote>"The body is the vehicle of consciousness." - Dr. Joe Dispenza</Quote>
          </PhysicalSection>
        )}

        {activeTab === 'integration' && (
          <IntegrationSection>
            <h2>Integration Practice</h2>
            <p>This afternoon practice helps integrate your morning awareness and physical observations into a cohesive experience. It introduces the concept of "mastering the little things" through mindful attention.</p>
            
            <h3>Mindful Moment Practice (10 minutes)</h3>
            <p>Choose a simple, everyday activity that you typically do on autopilot. This could be:</p>
            <ul>
              <li>Drinking a glass of water</li>
              <li>Walking from one room to another</li>
              <li>Washing your hands</li>
              <li>Eating a small snack</li>
            </ul>
            
            <p>Perform this activity with complete awareness, slowing down to notice every sensation:</p>
            <ol>
              <li>Observe the physical sensations (temperature, texture, weight, etc.)</li>
              <li>Notice any thoughts that arise (without judgment)</li>
              <li>Be aware of any emotions connected to the experience</li>
              <li>Pay attention to your breath throughout the activity</li>
            </ol>
            
            <p>This practice demonstrates how awareness transforms even the simplest activities into opportunities for presence and growth—the essence of "mastering the little things."</p>
            
            <h3>Journaling Prompt (5 minutes)</h3>
            <p>In your journal, reflect on the following questions:</p>
            <ul>
              <li>What did you notice during your body scan this morning that you weren't previously aware of?</li>
              <li>During the movement assessment, which patterns felt natural and which felt challenging?</li>
              <li>How did the quality of your experience change when you brought full awareness to your mindful moment practice?</li>
              <li>What is one "little thing" you could bring more awareness to in your daily life?</li>
            </ul>
            
            <Quote>"When you change the way you look at things, the things you look at change." - Dr. Wayne Dyer</Quote>
          </IntegrationSection>
        )}

        {activeTab === 'evening' && (
          <EveningSection>
            <h2>Evening Check-in</h2>
            <p>The evening check-in helps you integrate the day's practices and prepare for restful sleep. This consistent evening ritual will become an anchor throughout your 14-day journey.</p>
            
            <h3>Day 1 Reflection (5 minutes)</h3>
            <p>Find a quiet space where you can reflect on your first day. Sit comfortably and take three deep breaths to center yourself.</p>
            
            <p>Consider the following questions:</p>
            <ul>
              <li>What moments of awareness did you experience today?</li>
              <li>Did you notice any patterns or habits you weren't previously aware of?</li>
              <li>How did your body feel during and after the physical practice?</li>
              <li>What was challenging about maintaining awareness?</li>
              <li>What was rewarding about practicing awareness?</li>
            </ul>
            
            <h3>Gratitude Practice (3 minutes)</h3>
            <p>Identify three specific things you're grateful for today. They can be related to your practice or completely separate. For each item, take a moment to truly feel the gratitude in your body.</p>
            
            <h3>Tomorrow's Micro-Habit: Awareness Trigger (2 minutes)</h3>
            <p>Choose a specific trigger that will remind you to practice awareness throughout tomorrow. This could be:</p>
            <ul>
              <li>Every time you walk through a doorway</li>
              <li>Each time you check your phone</li>
              <li>Whenever you take a drink of water</li>
              <li>When you wash your hands</li>
            </ul>
            <p>When this trigger occurs, pause for three conscious breaths and notice your physical sensations, thoughts, and emotions in that moment.</p>
            
            <h3>Sleep Preparation (5 minutes)</h3>
            <p>Prepare your body and mind for restful sleep with this simple practice:</p>
            <ol>
              <li>Lie comfortably in bed</li>
              <li>Take five deep breaths, extending your exhale longer than your inhale</li>
              <li>Scan your body from head to toe, consciously relaxing each part</li>
              <li>Visualize yourself waking up refreshed and ready for Day 2</li>
            </ol>
            
            <Quote>"The day is over, the night is drawing nigh, let all that I've done today sink deep into my heart." - Traditional Evening Prayer</Quote>
          </EveningSection>
        )}

        {activeTab === 'resources' && (
          <ResourcesSection>
            <h2>Resources</h2>
            <p>These resources will deepen your understanding of awareness practices and support your Day 1 experience.</p>
            
            <h3>Recommended Reading</h3>
            <ResourceList>
              <ResourceItem>
                <h4>"The Body Keeps the Score" by Bessel van der Kolk</h4>
                <p>Explores how awareness of body sensations connects to emotional processing and healing.</p>
                <a href="https://www.besselvanderkolk.com/resources/the-body-keeps-the-score" target="_blank" rel="noopener noreferrer">Learn More</a>
              </ResourceItem>
              
              <ResourceItem>
                <h4>"The Untethered Soul" by Michael Singer</h4>
                <p>Provides insights on developing awareness of thoughts and emotions without being controlled by them.</p>
                <a href="https://untetheredsoul.com/untethered-soul" target="_blank" rel="noopener noreferrer">Learn More</a>
              </ResourceItem>
              
              <ResourceItem>
                <h4>"Wherever You Go, There You Are" by Jon Kabat-Zinn</h4>
                <p>A classic guide to mindfulness meditation and awareness in everyday life.</p>
                <a href="https://www.mindfulnesscds.com/pages/books-by-jon-kabat-zinn" target="_blank" rel="noopener noreferrer">Learn More</a>
              </ResourceItem>
            </ResourceList>
            
            <h3>Video Resources</h3>
            <ResourceList>
              <ResourceItem>
                <h4>"How to Do a Body Scan Meditation" - Mindful</h4>
                <p>A guided video for the body scan practice introduced today.</p>
                <a href="https://www.youtube.com/watch?v=QS2yDmWk0vs" target="_blank" rel="noopener noreferrer">Watch Video</a>
              </ResourceItem>
            </ResourceList>
            
            <h3>Scientific Research</h3>
            <ResourceList>
              <ResourceItem>
                <h4>"The Neurobiology of Mind-Body Medicine" - Journal of Psychosomatic Research</h4>
                <p>Research on the scientific basis for mind-body awareness practices.</p>
                <a href="https://www.sciencedirect.com/science/article/abs/pii/S0022399915000781" target="_blank" rel="noopener noreferrer">View Research</a>
              </ResourceItem>
              
              <ResourceItem>
                <h4>"Effects of Mindfulness on Psychological Health" - Clinical Psychology Review</h4>
                <p>Meta-analysis of research on mindfulness and awareness practices.</p>
                <a href="https://www.sciencedirect.com/science/article/abs/pii/S0272735811000584" target="_blank" rel="noopener noreferrer">View Research</a>
              </ResourceItem>
            </ResourceList>
            
            <h3>Downloadable Resources</h3>
            <ResourceList>
              <ResourceItem>
                <h4>Day 1 Practice Worksheet</h4>
                <p>Printable worksheet with today's practices and reflection questions.</p>
                <a href="/pdfs/day1_practice_worksheet.pdf" target="_blank" rel="noopener noreferrer">Download PDF</a>
              </ResourceItem>
              
              <ResourceItem>
                <h4>Awareness Techniques Guide</h4>
                <p>Comprehensive guide to awareness practices for mind, body, and spirit.</p>
                <a href="/pdfs/awareness_techniques.pdf" target="_blank" rel="noopener noreferrer">Download PDF</a>
              </ResourceItem>
            </ResourceList>
            
            <h3>Apps & Digital Tools</h3>
            <ResourceList>
              <ResourceItem>
                <h4>Insight Timer</h4>
                <p>Free guided meditations and timer for awareness practices.</p>
                <a href="https://insighttimer.com/" target="_blank" rel="noopener noreferrer">Visit Website</a>
              </ResourceItem>
              
              <ResourceItem>
                <h4>Headspace</h4>
                <p>Structured meditation courses for developing awareness.</p>
                <a href="https://www.headspace.com/" target="_blank" rel="noopener noreferrer">Visit Website</a>
              </ResourceItem>
            </ResourceList>
          </ResourcesSection>
        )}
      </DayLayout>
    </>
  );
};

// Styled Components
const MorningSection = styled.div`
  h2 {
    color: #D35400;
    margin-bottom: 1.5rem;
  }
  
  h3 {
    margin-top: 2rem;
    margin-bottom: 1rem;
  }
  
  p {
    line-height: 1.6;
    margin-bottom: 1rem;
  }
`;

const PhysicalSection = styled.div`
  h2 {
    color: #D35400;
    margin-bottom: 1.5rem;
  }
  
  h3, h4 {
    margin-top: 2rem;
    margin-bottom: 1rem;
  }
  
  p {
    line-height: 1.6;
    margin-bottom: 1rem;
  }
  
  ul {
    margin-bottom: 1.5rem;
    padding-left: 1.5rem;
    
    li {
      margin-bottom: 0.5rem;
    }
  }
`;

const MovementItem = styled.div`
  background-color: #2A2A2A;
  padding: 1.5rem;
  border-radius: 8px;
  margin-bottom: 1.5rem;
  
  h5 {
    color: #D35400;
    margin-bottom: 1rem;
  }
  
  p {
    margin-bottom: 0.5rem;
  }
`;

const IntegrationSection = styled.div`
  h2 {
    color: #D35400;
    margin-bottom: 1.5rem;
  }
  
  h3 {
    margin-top: 2rem;
    margin-bottom: 1rem;
  }
  
  p {
    line-height: 1.6;
    margin-bottom: 1rem;
  }
  
  ul, ol {
    margin-bottom: 1.5rem;
    padding-left: 1.5rem;
    
    li {
      margin-bottom: 0.5rem;
    }
  }
`;

const EveningSection = styled.div`
  h2 {
    color: #D35400;
    margin-bottom: 1.5rem;
  }
  
  h3 {
    margin-top: 2rem;
    margin-bottom: 1rem;
  }
  
  p {
    line-height: 1.6;
    margin-bottom: 1rem;
  }
  
  ul, ol {
    margin-bottom: 1.5rem;
    padding-left: 1.5rem;
    
    li {
      margin-bottom: 0.5rem;
    }
  }
`;

const ResourcesSection = styled.div`
  h2 {
    color: #D35400;
    margin-bottom: 1.5rem;
  }
  
  h3 {
    margin-top: 2rem;
    margin-bottom: 1rem;
  }
  
  p {
    line-height: 1.6;
    margin-bottom: 1rem;
  }
`;

const ResourceList = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 1.5rem;
  margin-bottom: 2rem;
`;

const ResourceItem = styled.div`
  background-color: #2A2A2A;
  padding: 1.5rem;
  border-radius: 8px;
  
  h4 {
    color: #D35400;
    margin-bottom: 0.5rem;
  }
  
  p {
    margin-bottom: 1rem;
  }
  
  a {
    color: #FFFFFF;
    background-color: #D35400;
    padding: 0.5rem 1rem;
    border-radius: 4px;
    text-decoration: none;
    display: inline-block;
    
    &:hover {
      background-color: #E67E22;
    }
  }
`;

const Quote = styled.blockquote`
  font-style: italic;
  border-left: 3px solid #D35400;
  padding-left: 1rem;
  margin: 2rem 0;
  color: #E67E22;
`;

export default Day1;
