import { useState } from 'react';
import Head from 'next/head';
import DayLayout from '../components/DayLayout';
import styled from 'styled-components';

const Day3 = () => {
  const [activeTab, setActiveTab] = useState('morning');

  return (
    <>
      <Head>
        <title>Day 3: Body Intelligence | Harmonized Fitness</title>
        <meta name="description" content="Develop body intelligence and explore the Root Chakra (Muladhara) to establish a strong foundation for your transformation journey." />
      </Head>

      <DayLayout day={3} title="Body Intelligence">
        {activeTab === 'morning' && (
          <MorningSection>
            <h2>Morning Ritual</h2>
            <p>Welcome to Day 3! Today we focus on body intelligence—your body's innate wisdom and ability to communicate with you. By developing this intelligence, you'll make better decisions about movement, nutrition, rest, and overall wellbeing.</p>
            
            <h3>Intention Setting (3 minutes)</h3>
            <p>Find your quiet space and sit comfortably. Take three deep breaths to center yourself. Today, set an intention related to body intelligence: "My intention is to listen to and honor the wisdom of my body."</p>
            
            <h3>Body Sensing Practice (7 minutes)</h3>
            <p>This practice develops your ability to sense subtle physical sensations:</p>
            <ol>
              <li>Sit or lie down comfortably with your eyes closed</li>
              <li>Bring awareness to your hands, noticing any sensations (temperature, tingling, pulsing, etc.)</li>
              <li>Rub your hands together vigorously for 10 seconds</li>
              <li>Hold your hands slightly apart and notice the sensations (energy, warmth, magnetic feeling)</li>
              <li>Slowly move your hands closer together and further apart, noticing how the sensations change</li>
              <li>Continue exploring these subtle sensations for several minutes</li>
            </ol>
            <p>This practice enhances your sensitivity to subtle body signals that are often overlooked.</p>
            
            <h3>Root Chakra Awareness (5 minutes)</h3>
            <ChakraElement color="#FF0000">
              <h4>Root Chakra (Muladhara)</h4>
              <p>Located at the base of your spine, the Root Chakra is associated with feelings of safety, security, and being grounded. It's represented by the color red and is connected to your basic survival needs.</p>
              <p>To activate your Root Chakra:</p>
              <ul>
                <li>Sit comfortably with your sit bones firmly on the ground</li>
                <li>Visualize a glowing red light at the base of your spine</li>
                <li>As you inhale, imagine this red energy expanding</li>
                <li>As you exhale, feel yourself becoming more grounded and stable</li>
                <li>Silently repeat: "I am safe. I am secure. I am grounded."</li>
              </ul>
              <p>A balanced Root Chakra provides the stable foundation needed for all other aspects of transformation.</p>
            </ChakraElement>
            
            <Quote>"The body has its own wisdom, and if you silence the chatter of the mind, you can hear it." - Deepak Chopra</Quote>
          </MorningSection>
        )}

        {activeTab === 'physical' && (
          <PhysicalSection>
            <h2>Physical Practice</h2>
            <p>Today's physical practice focuses on developing body intelligence through mindful movement and grounding exercises that strengthen your connection to the Root Chakra.</p>
            
            <h3>Grounding Movement Practice (25 minutes)</h3>
            <p>This practice emphasizes the connection between your body and the earth, enhancing stability and body awareness.</p>
            
            <h4>1. Warm-up: Sensory Awakening (5 minutes)</h4>
            <p>Stand barefoot if possible, with feet hip-width apart:</p>
            <ul>
              <li>Close your eyes and feel the connection between your feet and the ground</li>
              <li>Slowly shift your weight forward to your toes, then back to your heels</li>
              <li>Shift from side to side, noticing the changing pressure</li>
              <li>Make small circles with your hips, feeling how weight shifts through your feet</li>
              <li>Gradually increase the size of the circles, then reduce them again</li>
            </ul>
            <p><strong>Things to think about:</strong> Can you feel the different parts of your feet making contact with the ground? Notice how small adjustments in your hips affect your entire body.</p>
            
            <h4>2. Foundation Strengthening (10 minutes)</h4>
            <MovementItem>
              <h5>Rooted Squat</h5>
              <p>Stand with feet slightly wider than hip-width, toes turned out slightly:</p>
              <ul>
                <li>Before moving, visualize roots extending from your feet into the earth</li>
                <li>Inhale: Raise arms overhead</li>
                <li>Exhale: Hinge at hips and bend knees to lower into a squat</li>
                <li>Maintain a strong connection through your feet</li>
                <li>Inhale: Rise back up, bringing arms overhead</li>
                <li>Exhale: Lower arms to sides</li>
                <li>Repeat 10 times, moving slowly and mindfully</li>
              </ul>
              <p><strong>Things to think about:</strong> Can you keep your heels grounded throughout the movement? Notice the strength in your legs as they support you.</p>
            </MovementItem>
            
            <MovementItem>
              <h5>Stable Warrior</h5>
              <p>Begin standing at the front of your space:</p>
              <ul>
                <li>Step your left foot back about 3-4 feet, turning it out slightly</li>
                <li>Bend your right knee to 90 degrees, keeping it aligned with your ankle</li>
                <li>Raise arms to shoulder height, parallel to the ground</li>
                <li>Gaze over your right fingertips</li>
                <li>Hold for 5 breaths, feeling the stability in your legs</li>
                <li>Repeat on the other side</li>
                <li>Complete 3 rounds on each side</li>
              </ul>
              <p><strong>Things to think about:</strong> Can you feel the strength of your foundation through both feet? Notice how your core engages to keep you stable.</p>
            </MovementItem>
            
            <h4>3. Grounding Flow (10 minutes)</h4>
            <p>Move through this sequence at a slow, mindful pace, focusing on the sensations in your body:</p>
            
            <MovementItem>
              <h5>Mountain to Forward Fold Flow</h5>
              <p>Begin standing in Mountain Pose (feet hip-width apart, standing tall):</p>
              <ul>
                <li>Inhale: Feel your connection to the earth while reaching arms overhead</li>
                <li>Exhale: Hinge at hips to fold forward, bringing hands toward floor</li>
                <li>Inhale: Lift halfway up, extending spine forward</li>
                <li>Exhale: Fold forward again</li>
                <li>Inhale: Rise all the way up, bringing arms overhead</li>
                <li>Exhale: Return to Mountain Pose</li>
                <li>Repeat 5 times, moving with your breath</li>
              </ul>
              <p><strong>Things to think about:</strong> Can you feel the relationship between your breath and movement? Notice the sensation of gravity as you fold forward.</p>
            </MovementItem>
            
            <MovementItem>
              <h5>Grounding Balance Practice</h5>
              <p>Begin standing in Mountain Pose:</p>
              <ul>
                <li>Shift weight to your right foot, grounding down firmly</li>
                <li>Slowly lift your left foot, bringing knee toward chest</li>
                <li>Find a focal point at eye level to help with balance</li>
                <li>Hold for 5 breaths, focusing on stability through your standing leg</li>
                <li>Slowly lower and repeat on the other side</li>
                <li>Complete 3 rounds on each side</li>
              </ul>
              <p><strong>Things to think about:</strong> How does your body make subtle adjustments to maintain balance? Notice which muscles engage to keep you stable.</p>
            </MovementItem>
            
            <Quote>"Your body is the ground metaphor of your life, the expression of your existence." - Gabrielle Roth</Quote>
          </PhysicalSection>
        )}

        {activeTab === 'integration' && (
          <IntegrationSection>
            <h2>Integration Practice</h2>
            <p>This afternoon practice helps you integrate body intelligence into your daily activities, strengthening your connection to physical sensations and the Root Chakra.</p>
            
            <h3>Body Intelligence Check-ins (Throughout the Day)</h3>
            <p>Set a timer to remind you every 2 hours to perform a quick body intelligence check-in:</p>
            <ol>
              <li>Pause whatever you're doing for 30 seconds</li>
              <li>Scan your body from head to toe, noticing any sensations</li>
              <li>Ask your body: "What do you need right now?"</li>
              <li>Listen for the response (it might be water, movement, rest, etc.)</li>
              <li>Honor that need if possible, or acknowledge it if you can't address it immediately</li>
            </ol>
            <p>This practice strengthens your ability to interpret and respond to your body's signals.</p>
            
            <h3>Grounding Practice for Stress (5 minutes)</h3>
            <p>When you feel stressed or disconnected, use this quick grounding technique:</p>
            <ol>
              <li>Find a place to sit or stand comfortably</li>
              <li>Focus on the points where your body contacts the ground or chair</li>
              <li>Press your feet firmly into the floor</li>
              <li>Take 5 deep breaths, visualizing roots extending from your body into the earth</li>
              <li>Mentally repeat: "I am here. I am safe. I am grounded."</li>
            </ol>
            <p>This practice activates your Root Chakra and brings you back to the present moment.</p>
            
            <h3>Journaling Prompt (5 minutes)</h3>
            <p>In your journal, reflect on the following questions:</p>
            <ul>
              <li>What sensations did you notice during today's body sensing practice?</li>
              <li>How did the grounding movement practice affect your sense of stability?</li>
              <li>What signals has your body been sending that you might have been ignoring?</li>
              <li>How might developing body intelligence impact your daily decisions?</li>
              <li>What does feeling "grounded" mean to you personally?</li>
            </ul>
            
            <Quote>"The body never lies." - Martha Graham</Quote>
          </IntegrationSection>
        )}

        {activeTab === 'evening' && (
          <EveningSection>
            <h2>Evening Check-in</h2>
            <p>This evening practice helps you integrate today's focus on body intelligence and the Root Chakra, preparing you for restful sleep and tomorrow's journey.</p>
            
            <h3>Day 3 Reflection (5 minutes)</h3>
            <p>Find your quiet space and take three deep breaths to center yourself. Reflect on the following questions:</p>
            <ul>
              <li>What new body sensations did you become aware of today?</li>
              <li>How did focusing on your Root Chakra affect your sense of stability?</li>
              <li>Did you notice any patterns in how your body communicates with you?</li>
              <li>Were you able to honor your body's needs when they arose?</li>
              <li>How did the grounding practices affect your overall state?</li>
            </ul>
            
            <h3>Gratitude Practice (3 minutes)</h3>
            <p>Identify three specific things about your body that you're grateful for today. For each item, place your hand on that part of your body and silently express gratitude for its function and wisdom.</p>
            
            <h3>Tomorrow's Micro-Habit: Posture Check (2 minutes)</h3>
            <p>Set an intention to check and adjust your posture at least 5 times throughout tomorrow. When you do:</p>
            <ol>
              <li>Notice your current posture without judgment</li>
              <li>Make small adjustments to align your spine</li>
              <li>Feel your sit bones or feet connecting to the ground</li>
              <li>Take one conscious breath in this aligned position</li>
            </ol>
            <p>This micro-habit reinforces body awareness and proper alignment throughout your day.</p>
            
            <h3>Root Chakra Sleep Visualization (5 minutes)</h3>
            <p>Prepare for sleep with this grounding visualization:</p>
            <ol>
              <li>Lie comfortably in bed</li>
              <li>Visualize a warm, glowing red light at the base of your spine</li>
              <li>With each exhale, imagine this energy expanding to create a stable foundation beneath you</li>
              <li>Feel your body becoming heavier and more relaxed with each breath</li>
              <li>Visualize yourself completely supported by the earth beneath you</li>
              <li>Allow this sense of safety and support to carry you into sleep</li>
            </ol>
            
            <Quote>"Listen to your body's wisdom, which expresses itself through signals of comfort and discomfort." - Peter Levine</Quote>
          </EveningSection>
        )}

        {activeTab === 'resources' && (
          <ResourcesSection>
            <h2>Resources</h2>
            <p>These resources will deepen your understanding of body intelligence and the Root Chakra to support your Day 3 experience.</p>
            
            <h3>Recommended Reading</h3>
            <ResourceList>
              <ResourceItem>
                <h4>"The Body Keeps the Score" by Bessel van der Kolk</h4>
                <p>Explores how the body stores experiences and how to develop body awareness for healing.</p>
                <a href="https://www.besselvanderkolk.com/resources/the-body-keeps-the-score" target="_blank" rel="noopener noreferrer">Learn More</a>
              </ResourceItem>
              
              <ResourceItem>
                <h4>"Eastern Body, Western Mind" by Anodea Judith</h4>
                <p>Comprehensive guide to the chakra system, with detailed information on the Root Chakra.</p>
                <a href="https://anodeajudith.com/books/eastern-body-western-mind/" target="_blank" rel="noopener noreferrer">Learn More</a>
              </ResourceItem>
              
              <ResourceItem>
                <h4>"The Mind-Gut Connection" by Emeran Mayer</h4>
                <p>Explores the connection between gut health and overall wellbeing.</p>
                <a href="https://emeranmayer.com/the-mind-gut-connection-book/" target="_blank" rel="noopener noreferrer">Learn More</a>
              </ResourceItem>
            </ResourceList>
            
            <h3>Video Resources</h3>
            <ResourceList>
              <ResourceItem>
                <h4>"Introduction to the Chakra System" - Anodea Judith</h4>
                <p>Overview of the seven chakras with focus on the Root Chakra.</p>
                <a href="https://www.youtube.com/watch?v=StrbppmsZJw" target="_blank" rel="noopener noreferrer">Watch Video</a>
              </ResourceItem>
            </ResourceList>
            
            <h3>Scientific Research</h3>
            <ResourceList>
              <ResourceItem>
                <h4>"The Neurobiology of Mind-Body Medicine" - Journal of Psychosomatic Research</h4>
                <p>Research on the scientific basis for mind-body awareness practices.</p>
                <a href="https://www.sciencedirect.com/science/article/abs/pii/S0022399915000781" target="_blank" rel="noopener noreferrer">View Research</a>
              </ResourceItem>
            </ResourceList>
            
            <h3>Downloadable Resources</h3>
            <ResourceList>
              <ResourceItem>
                <h4>Day 3 Practice Worksheet</h4>
                <p>Printable worksheet with today's practices and reflection questions.</p>
                <a href="/pdfs/day3_practice_worksheet.pdf" target="_blank" rel="noopener noreferrer">Download PDF</a>
              </ResourceItem>
              
              <ResourceItem>
                <h4>Body Intelligence Guide</h4>
                <p>Comprehensive guide to developing and applying body intelligence.</p>
                <a href="/pdfs/body_intelligence_guide.pdf" target="_blank" rel="noopener noreferrer">Download PDF</a>
              </ResourceItem>
              
              <ResourceItem>
                <h4>Chakra System Reference Guide</h4>
                <p>Complete guide to the chakra system with practices for each energy center.</p>
                <a href="/pdfs/chakra_system_reference_guide.pdf" target="_blank" rel="noopener noreferrer">Download PDF</a>
              </ResourceItem>
            </ResourceList>
            
            <h3>Apps & Digital Tools</h3>
            <ResourceList>
              <ResourceItem>
                <h4>Insight Timer</h4>
                <p>Features guided meditations for body awareness and chakra balancing.</p>
                <a href="https://insighttimer.com/" target="_blank" rel="noopener noreferrer">Visit Website</a>
              </ResourceItem>
              
              <ResourceItem>
                <h4>Journey</h4>
                <p>Digital journaling app for tracking body awareness insights.</p>
                <a href="https://www.journey.cloud/" target="_blank" rel="noopener noreferrer">Visit Website</a>
              </ResourceItem>
            </ResourceList>
          </ResourcesSection>
        )}
      </DayLayout>
    </>
  );
};

// Styled Components
const MorningSection = styled.div`
  h2 {
    color: #D35400;
    margin-bottom: 1.5rem;
  }
  
  h3 {
    margin-top: 2rem;
    margin-bottom: 1rem;
  }
  
  p {
    line-height: 1.6;
    margin-bottom: 1rem;
  }
  
  ol {
    margin-bottom: 1.5rem;
    padding-left: 1.5rem;
    
    li {
      margin-bottom: 0.5rem;
    }
  }
`;

const ChakraElement = styled.div`
  background-color: #2A2A2A;
  padding: 1.5rem;
  border-radius: 8px;
  margin: 2rem 0;
  border-left: 5px solid ${props => props.color};
  
  h4 {
    color: ${props => props.color};
    margin-bottom: 1rem;
  }
  
  p {
    margin-bottom: 1rem;
  }
  
  ul {
    margin-bottom: 1.5rem;
    padding-left: 1.5rem;
    
    li {
      margin-bottom: 0.5rem;
    }
  }
`;

const PhysicalSection = styled.div`
  h2 {
    color: #D35400;
    margin-bottom: 1.5rem;
  }
  
  h3, h4 {
    margin-top: 2rem;
    margin-bottom: 1rem;
  }
  
  p {
    line-height: 1.6;
    margin-bottom: 1rem;
  }
  
  ul {
    margin-bottom: 1.5rem;
    padding-left: 1.5rem;
    
    li {
      margin-bottom: 0.5rem;
    }
  }
`;

const MovementItem = styled.div`
  background-color: #2A2A2A;
  padding: 1.5rem;
  border-radius: 8px;
  margin-bottom: 1.5rem;
  
  h5 {
    color: #D35400;
    margin-bottom: 1rem;
  }
  
  p {
    margin-bottom: 0.5rem;
  }
  
  ul {
    margin-bottom: 1rem;
  }
`;

const IntegrationSection = styled.div`
  h2 {
    color: #D35400;
    margin-bottom: 1.5rem;
  }
  
  h3 {
    margin-top: 2rem;
    margin-bottom: 1rem;
  }
  
  p {
    line-height: 1.6;
    margin-bottom: 1rem;
  }
  
  ul, ol {
    margin-bottom: 1.5rem;
    padding-left: 1.5rem;
    
    li {
      margin-bottom: 0.5rem;
    }
  }
`;

const EveningSection = styled.div`
  h2 {
    color: #D35400;
    margin-bottom: 1.5rem;
  }
  
  h3 {
    margin-top: 2rem;
    margin-bottom: 1rem;
  }
  
  p {
    line-height: 1.6;
    margin-bottom: 1rem;
  }
  
  ul, ol {
    margin-bottom: 1.5rem;
    padding-left: 1.5rem;
    
    li {
      margin-bottom: 0.5rem;
    }
  }
`;

const ResourcesSection = styled.div`
  h2 {
    color: #D35400;
    margin-bottom: 1.5rem;
  }
  
  h3 {
    margin-top: 2rem;
    margin-bottom: 1rem;
  }
  
  p {
    line-height: 1.6;
    margin-bottom: 1rem;
  }
`;

const ResourceList = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 1.5rem;
  margin-bottom: 2rem;
`;

const ResourceItem = styled.div`
  background-color: #2A2A2A;
  padding: 1.5rem;
  border-radius: 8px;
  
  h4 {
    color: #D35400;
    margin-bottom: 0.5rem;
  }
  
  p {
    margin-bottom: 1rem;
  }
  
  a {
    color: #FFFFFF;
    background-color: #D35400;
    padding: 0.5rem 1rem;
    border-radius: 4px;
    text-decoration: none;
    display: inline-block;
    
    &:hover {
      background-color: #E67E22;
    }
  }
`;

const Quote = styled.blockquote`
  font-style: italic;
  border-left: 3px solid #D35400;
  padding-left: 1rem;
  margin: 2rem 0;
  color: #E67E22;
`;

export default Day3;
