import styled from 'styled-components';
import PDFTemplate from '../components/PDFTemplate';

const Day1Worksheet = () => {
  return (
    <PDFTemplate title="Day 1: Awakening Awareness - Practice Worksheet">
      <Section>
        <SectionTitle>Morning Ritual</SectionTitle>
        
        <Exercise>
          <ExerciseTitle>Intention Setting (5 minutes)</ExerciseTitle>
          <Instructions>
            <p>Find a quiet space where you won't be disturbed. Sit comfortably with your spine straight but not rigid. Close your eyes and take three deep breaths, feeling your body settle into the present moment.</p>
            <p>Ask yourself: "What is my intention for this 14-day journey?" Listen for the answer that arises naturally.</p>
          </Instructions>
          <Worksheet>
            <Question>My intention for this 14-day journey is:</Question>
            <AnswerSpace />
            
            <Question>I will know I've honored this intention when:</Question>
            <AnswerSpace />
          </Worksheet>
        </Exercise>
        
        <Exercise>
          <ExerciseTitle>Body Scan (10 minutes)</ExerciseTitle>
          <Instructions>
            <p>Remaining in your seated position, bring your awareness to your body. Starting at the crown of your head, slowly move your attention downward, noticing sensations without judgment.</p>
          </Instructions>
          <Worksheet>
            <BodyMapTitle>Body Awareness Map</BodyMapTitle>
            <BodyMapInstructions>Mark areas where you noticed tension (T), comfort (C), or neutrality (N).</BodyMapInstructions>
            <BodyMapImage>
              [Body outline diagram would appear here]
            </BodyMapImage>
            
            <Question>What was the most prominent sensation you noticed?</Question>
            <AnswerSpace />
            
            <Question>Was there any area that surprised you with how it felt?</Question>
            <AnswerSpace />
          </Worksheet>
        </Exercise>
      </Section>
      
      <Section>
        <SectionTitle>Physical Practice</SectionTitle>
        
        <Exercise>
          <ExerciseTitle>Movement Assessment (15 minutes)</ExerciseTitle>
          <Instructions>
            <p>Perform each movement slowly, focusing on form and how your body feels.</p>
          </Instructions>
          <Worksheet>
            <MovementAssessment>
              <MovementTitle>Squat (5 reps)</MovementTitle>
              <CheckboxGroup>
                <CheckboxItem>
                  <CheckboxLabel>Easy to keep heels down</CheckboxLabel>
                  <Checkbox />
                </CheckboxItem>
                <CheckboxItem>
                  <CheckboxLabel>Knees track over toes</CheckboxLabel>
                  <Checkbox />
                </CheckboxItem>
                <CheckboxItem>
                  <CheckboxLabel>Lower back remains neutral</CheckboxLabel>
                  <Checkbox />
                </CheckboxItem>
              </CheckboxGroup>
              <Question>Where did you feel tension during this movement?</Question>
              <AnswerSpace small />
            </MovementAssessment>
            
            <MovementAssessment>
              <MovementTitle>Push-up or Wall Push (5 reps)</MovementTitle>
              <CheckboxGroup>
                <CheckboxItem>
                  <CheckboxLabel>Maintained straight body line</CheckboxLabel>
                  <Checkbox />
                </CheckboxItem>
                <CheckboxItem>
                  <CheckboxLabel>Felt balanced between both arms</CheckboxLabel>
                  <Checkbox />
                </CheckboxItem>
                <CheckboxItem>
                  <CheckboxLabel>Shoulders stayed away from ears</CheckboxLabel>
                  <Checkbox />
                </CheckboxItem>
              </CheckboxGroup>
              <Question>Where did you feel tension during this movement?</Question>
              <AnswerSpace small />
            </MovementAssessment>
            
            <MovementAssessment>
              <MovementTitle>Hip Hinge (5 reps)</MovementTitle>
              <CheckboxGroup>
                <CheckboxItem>
                  <CheckboxLabel>Movement came from hips (not lower back)</CheckboxLabel>
                  <Checkbox />
                </CheckboxItem>
                <CheckboxItem>
                  <CheckboxLabel>Felt hamstrings engage</CheckboxLabel>
                  <Checkbox />
                </CheckboxItem>
                <CheckboxItem>
                  <CheckboxLabel>Maintained neutral spine</CheckboxLabel>
                  <Checkbox />
                </CheckboxItem>
              </CheckboxGroup>
              <Question>Where did you feel tension during this movement?</Question>
              <AnswerSpace small />
            </MovementAssessment>
          </Worksheet>
        </Exercise>
      </Section>
      
      <Section>
        <SectionTitle>Integration Practice</SectionTitle>
        
        <Exercise>
          <ExerciseTitle>Mindful Moment Practice (10 minutes)</ExerciseTitle>
          <Instructions>
            <p>Choose a simple, everyday activity that you typically do on autopilot. Perform this activity with complete awareness, slowing down to notice every sensation.</p>
          </Instructions>
          <Worksheet>
            <Question>Activity chosen:</Question>
            <AnswerSpace small />
            
            <Question>Physical sensations noticed:</Question>
            <AnswerSpace small />
            
            <Question>Thoughts that arose:</Question>
            <AnswerSpace small />
            
            <Question>Emotions experienced:</Question>
            <AnswerSpace small />
            
            <Question>How did the quality of your experience change with awareness?</Question>
            <AnswerSpace />
          </Worksheet>
        </Exercise>
        
        <Exercise>
          <ExerciseTitle>Journaling Prompt (5 minutes)</ExerciseTitle>
          <Worksheet>
            <Question>What did you notice during your body scan this morning that you weren't previously aware of?</Question>
            <AnswerSpace />
            
            <Question>During the movement assessment, which patterns felt natural and which felt challenging?</Question>
            <AnswerSpace />
            
            <Question>What is one "little thing" you could bring more awareness to in your daily life?</Question>
            <AnswerSpace />
          </Worksheet>
        </Exercise>
      </Section>
      
      <Section>
        <SectionTitle>Evening Check-in</SectionTitle>
        
        <Exercise>
          <ExerciseTitle>Day 1 Reflection (5 minutes)</ExerciseTitle>
          <Worksheet>
            <Question>What moments of awareness did you experience today?</Question>
            <AnswerSpace />
            
            <Question>Did you notice any patterns or habits you weren't previously aware of?</Question>
            <AnswerSpace />
            
            <Question>What was challenging about maintaining awareness?</Question>
            <AnswerSpace />
            
            <Question>What was rewarding about practicing awareness?</Question>
            <AnswerSpace />
          </Worksheet>
        </Exercise>
        
        <Exercise>
          <ExerciseTitle>Gratitude Practice (3 minutes)</ExerciseTitle>
          <Worksheet>
            <Question>Three specific things I'm grateful for today:</Question>
            <NumberedAnswer number="1" />
            <NumberedAnswer number="2" />
            <NumberedAnswer number="3" />
          </Worksheet>
        </Exercise>
        
        <Exercise>
          <ExerciseTitle>Tomorrow's Micro-Habit: Awareness Trigger (2 minutes)</ExerciseTitle>
          <Worksheet>
            <Question>My awareness trigger for tomorrow will be:</Question>
            <CheckboxGroup>
              <CheckboxItem>
                <CheckboxLabel>Walking through a doorway</CheckboxLabel>
                <Checkbox />
              </CheckboxItem>
              <CheckboxItem>
                <CheckboxLabel>Checking my phone</CheckboxLabel>
                <Checkbox />
              </CheckboxItem>
              <CheckboxItem>
                <CheckboxLabel>Taking a drink of water</CheckboxLabel>
                <Checkbox />
              </CheckboxItem>
              <CheckboxItem>
                <CheckboxLabel>Washing my hands</CheckboxLabel>
                <Checkbox />
              </CheckboxItem>
              <CheckboxItem>
                <CheckboxLabel>Other:</CheckboxLabel>
                <AnswerSpace inline small />
              </CheckboxItem>
            </CheckboxGroup>
          </Worksheet>
        </Exercise>
      </Section>
      
      <QuoteBox>
        "When you change the way you look at things, the things you look at change." - Dr. Wayne Dyer
      </QuoteBox>
    </PDFTemplate>
  );
};

// Styled Components
const Section = styled.div`
  margin-bottom: 40px;
`;

const SectionTitle = styled.h2`
  font-size: 24px;
  color: #D35400;
  margin-bottom: 20px;
  padding-bottom: 10px;
  border-bottom: 1px solid #444444;
`;

const Exercise = styled.div`
  margin-bottom: 30px;
`;

const ExerciseTitle = styled.h3`
  font-size: 20px;
  color: #FFFFFF;
  margin-bottom: 15px;
`;

const Instructions = styled.div`
  background-color: #333333;
  padding: 15px;
  border-radius: 8px;
  margin-bottom: 20px;
  
  p {
    margin-bottom: 10px;
    line-height: 1.5;
    
    &:last-child {
      margin-bottom: 0;
    }
  }
`;

const Worksheet = styled.div`
  background-color: #333333;
  padding: 20px;
  border-radius: 8px;
`;

const Question = styled.p`
  font-weight: bold;
  margin-bottom: 10px;
`;

const AnswerSpace = styled.div`
  height: ${props => props.small ? '40px' : '80px'};
  width: ${props => props.inline ? '200px' : 'auto'};
  display: ${props => props.inline ? 'inline-block' : 'block'};
  background-color: #2A2A2A;
  border: 1px solid #444444;
  border-radius: 4px;
  margin-bottom: 20px;
`;

const BodyMapTitle = styled.h4`
  font-size: 18px;
  color: #D35400;
  margin-bottom: 10px;
  text-align: center;
`;

const BodyMapInstructions = styled.p`
  text-align: center;
  margin-bottom: 15px;
  font-style: italic;
`;

const BodyMapImage = styled.div`
  height: 300px;
  background-color: #2A2A2A;
  border: 1px solid #444444;
  border-radius: 4px;
  margin-bottom: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #666666;
`;

const MovementAssessment = styled.div`
  margin-bottom: 25px;
  
  &:last-child {
    margin-bottom: 0;
  }
`;

const MovementTitle = styled.h4`
  font-size: 18px;
  color: #D35400;
  margin-bottom: 10px;
`;

const CheckboxGroup = styled.div`
  margin-bottom: 15px;
`;

const CheckboxItem = styled.div`
  display: flex;
  align-items: center;
  margin-bottom: 8px;
  
  &:last-child {
    margin-bottom: 0;
  }
`;

const CheckboxLabel = styled.label`
  flex: 1;
`;

const Checkbox = styled.div`
  width: 20px;
  height: 20px;
  background-color: #2A2A2A;
  border: 1px solid #444444;
  border-radius: 4px;
`;

const NumberedAnswer = styled.div`
  display: flex;
  margin-bottom: 15px;
  
  &:before {
    content: "${props => props.number}.";
    margin-right: 10px;
  }
  
  &:after {
    content: "";
    flex: 1;
    border-bottom: 1px solid #444444;
    margin-left: 10px;
  }
`;

const QuoteBox = styled.blockquote`
  font-style: italic;
  text-align: center;
  color: #D35400;
  margin: 40px 0;
  padding: 20px;
  background-color: #333333;
  border-radius: 8px;
  font-size: 18px;
`;

export default Day1Worksheet;
