import Head from 'next/head';
import { useState } from 'react';
import styled from 'styled-components';

// Components will be imported here
// import Hero from '../components/Hero';
// import ProblemSolution from '../components/ProblemSolution';
// import BreatheCode from '../components/BreatheCode';
// import PreludeOverview from '../components/PreludeOverview';
// import DailyStructure from '../components/DailyStructure';
// import DrU from '../components/DrU';
// import MilitaryFocus from '../components/MilitaryFocus';
// import Pricing from '../components/Pricing';
// import Testimonials from '../components/Testimonials';
// import FAQ from '../components/FAQ';
// import CallToAction from '../components/CallToAction';
// import Footer from '../components/Footer';

const HomePage = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <Container>
      <Head>
        <title>Harmonized Fitness | 14-Day "Master the Little Things" Prelude</title>
        <meta name="description" content="Transform your mind, body, and spirit with our 14-day prelude program. Guided by Dr. U, discover the power of small, consistent actions." />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <header>
        <nav>
          <Logo>Harmonized Fitness</Logo>
          <MenuButton onClick={() => setIsMenuOpen(!isMenuOpen)}>
            <span></span>
            <span></span>
            <span></span>
          </MenuButton>
          <NavLinks isOpen={isMenuOpen}>
            <li><a href="#about">About</a></li>
            <li><a href="#breathe">B.R.E.A.T.H.E.</a></li>
            <li><a href="#prelude">14-Day Prelude</a></li>
            <li><a href="#dru">Dr. U</a></li>
            <li><a href="#pricing">Pricing</a></li>
            <li><a href="#testimonials">Testimonials</a></li>
            <li><a href="#faq">FAQ</a></li>
            <li><a href="#signup" className="cta-button">Sign Up</a></li>
          </NavLinks>
        </nav>
      </header>

      <main>
        {/* Hero Section */}
        <HeroSection id="hero">
          <HeroContent>
            <h1>Master the Little Things</h1>
            <p>Transform your mind, body, and spirit with our 14-day prelude program. Discover how small, consistent actions create powerful change.</p>
            <CTAButton href="#signup">Start Your Journey</CTAButton>
          </HeroContent>
        </HeroSection>

        {/* Problem/Solution Section */}
        <Section id="about">
          <SectionTitle>A New Approach to Fitness</SectionTitle>
          <TwoColumn>
            <Column>
              <h3>The Problem</h3>
              <p>Traditional fitness programs focus solely on physical training, ignoring the crucial mind-body-spirit connection. This leads to temporary results, burnout, and a cycle of starting over.</p>
            </Column>
            <Column>
              <h3>Our Solution</h3>
              <p>Harmonized Fitness integrates physical training with mental clarity and spiritual awareness. By addressing all dimensions of your being, we create sustainable transformation from the inside out.</p>
            </Column>
          </TwoColumn>
        </Section>

        {/* B.R.E.A.T.H.E. Code Section */}
        <Section id="breathe" className="dark">
          <SectionTitle>The B.R.E.A.T.H.E. Code</SectionTitle>
          <p className="section-description">Our foundational philosophy for mind-body-spirit alignment</p>
          
          <BreatheGrid>
            <BreatheItem color="#FF0000">
              <h3><span>B</span>e the Change</h3>
              <p>Embody the transformation you want to see</p>
            </BreatheItem>
            <BreatheItem color="#FF8000">
              <h3><span>R</span>ecognize</h3>
              <p>Acknowledge your feelings and experiences</p>
            </BreatheItem>
            <BreatheItem color="#FFFF00">
              <h3><span>E</span>mpathy</h3>
              <p>Cultivate compassion for yourself and others</p>
            </BreatheItem>
            <BreatheItem color="#00FF00">
              <h3><span>A</span>lignment</h3>
              <p>Align your actions with your values</p>
            </BreatheItem>
            <BreatheItem color="#0000FF">
              <h3><span>T</span>rust</h3>
              <p>Trust the process and your journey</p>
            </BreatheItem>
            <BreatheItem color="#4B0082">
              <h3><span>H</span>old Space</h3>
              <p>Create space for yourself and others to grow</p>
            </BreatheItem>
            <BreatheItem color="#8A2BE2">
              <h3><span>E</span>xhale</h3>
              <p>Let go of tension and embrace the present moment</p>
            </BreatheItem>
          </BreatheGrid>
        </Section>

        {/* 14-Day Prelude Overview */}
        <Section id="prelude">
          <SectionTitle>14-Day "Master the Little Things" Prelude</SectionTitle>
          <p className="section-description">Your gateway to sustainable transformation</p>
          
          <PreludeGrid>
            <PreludeItem>
              <h3>Daily Structure</h3>
              <p>Each day includes morning rituals, physical practices, integration exercises, and evening check-ins designed to build awareness and create positive habits.</p>
            </PreludeItem>
            <PreludeItem>
              <h3>Mind-Body-Spirit Focus</h3>
              <p>Balance physical training with mental clarity techniques and spiritual awareness practices for complete wellbeing.</p>
            </PreludeItem>
            <PreludeItem>
              <h3>Progressive Journey</h3>
              <p>Follow a carefully designed progression that builds day by day, creating a foundation for lasting change.</p>
            </PreludeItem>
            <PreludeItem>
              <h3>Personalized Guidance</h3>
              <p>Receive customized support from Dr. U, your AI coach who adapts to your unique needs and progress.</p>
            </PreludeItem>
          </PreludeGrid>
          
          <DaysList>
            <DayItem>Day 1: Awakening Awareness</DayItem>
            <DayItem>Day 2: Breath & Presence</DayItem>
            <DayItem>Day 3: Body Intelligence</DayItem>
            <DayItem>Day 4: Emotional Awareness</DayItem>
            <DayItem>Day 5: Mental Patterns</DayItem>
            <DayItem>Day 6: Stress Resilience</DayItem>
            <DayItem>Day 7: Habit Formation</DayItem>
            <DayItem>Day 8: Energy Cultivation</DayItem>
            <DayItem>Day 9: Intuitive Nutrition</DayItem>
            <DayItem>Day 10: Rest & Recovery</DayItem>
            <DayItem>Day 11: Communication & Expression</DayItem>
            <DayItem>Day 12: Mindfulness & Presence</DayItem>
            <DayItem>Day 13: Intuition & Inner Guidance</DayItem>
            <DayItem>Day 14: Integration & Continuation</DayItem>
          </DaysList>
        </Section>

        {/* Dr. U Section */}
        <Section id="dru" className="dark">
          <SectionTitle>Meet Dr. U</SectionTitle>
          <p className="section-description">Your personal AI coach and guide</p>
          
          <TwoColumn>
            <Column>
              <img src="/images/dr-u-placeholder.jpg" alt="Dr. U AI Coach" />
            </Column>
            <Column>
              <h3>Personalized Guidance</h3>
              <p>Dr. U combines the wisdom of a veteran, the discipline of an athlete, and the mindfulness of a spiritual seeker to provide personalized coaching that adapts to your needs.</p>
              <h3>Always Available</h3>
              <p>Whether you have questions about practices, need motivation, or want to discuss your progress, Dr. U is available 24/7 to support your journey.</p>
              <h3>Evidence-Based Approach</h3>
              <p>Dr. U's guidance is grounded in cutting-edge research on behavior change, neuroscience, and performance optimization.</p>
            </Column>
          </TwoColumn>
        </Section>

        {/* Military/Veteran Focus */}
        <Section id="military">
          <SectionTitle>Military & Veteran Focus</SectionTitle>
          <p className="section-description">Specialized support for those who serve</p>
          
          <TwoColumn>
            <Column>
              <h3>Unique Understanding</h3>
              <p>Our program recognizes the distinct challenges and strengths of military personnel and veterans, providing relevant practices and support.</p>
              <h3>Transition Support</h3>
              <p>Whether you're active duty, transitioning to civilian life, or a veteran, our program helps you navigate change with resilience and purpose.</p>
              <h3>Community Connection</h3>
              <p>Connect with fellow service members and veterans who share your commitment to growth and wellbeing.</p>
            </Column>
            <Column>
              <img src="/images/military-focus-placeholder.jpg" alt="Military and Veteran Focus" />
            </Column>
          </TwoColumn>
        </Section>

        {/* Pricing Section */}
        <Section id="pricing" className="dark">
          <SectionTitle>Simple, Transparent Pricing</SectionTitle>
          <p className="section-description">Choose the plan that fits your needs</p>
          
          <PricingGrid>
            <PricingCard>
              <h3>Basic</h3>
              <PriceTag>$49</PriceTag>
              <p>14-Day Prelude Program</p>
              <ul>
                <li>Daily content access</li>
                <li>Basic Dr. U support</li>
                <li>Practice library</li>
                <li>Progress tracking</li>
              </ul>
              <CTAButton href="#signup">Get Started</CTAButton>
            </PricingCard>
            
            <PricingCard featured>
              <h3>Premium</h3>
              <PriceTag>$79</PriceTag>
              <p>Enhanced Experience</p>
              <ul>
                <li>Everything in Basic</li>
                <li>Advanced Dr. U features</li>
                <li>Community access</li>
                <li>Exclusive resources</li>
                <li>Email support</li>
              </ul>
              <CTAButton href="#signup">Get Started</CTAButton>
            </PricingCard>
            
            <PricingCard>
              <h3>Elite</h3>
              <PriceTag>$129</PriceTag>
              <p>Complete Transformation</p>
              <ul>
                <li>Everything in Premium</li>
                <li>1:1 coaching session</li>
                <li>Personalized plan</li>
                <li>Priority support</li>
                <li>Lifetime access</li>
              </ul>
              <CTAButton href="#signup">Get Started</CTAButton>
            </PricingCard>
          </PricingGrid>
          
          <MilitaryDiscount>
            <h3>Military Discount</h3>
            <p>Active duty, veterans, and military families receive 20% off any plan. Verification required.</p>
          </MilitaryDiscount>
        </Section>

        {/* Testimonials Section */}
        <Section id="testimonials">
          <SectionTitle>Success Stories</SectionTitle>
          <p className="section-description">Hear from those who've experienced the transformation</p>
          
          <TestimonialsGrid>
            <TestimonialCard>
              <img src="/images/testimonial1-placeholder.jpg" alt="Testimonial 1" />
              <h3>James R.</h3>
              <p className="role">Marine Corps Veteran</p>
              <p>"The 14-Day Prelude gave me tools to manage stress that I wish I'd had during active duty. The B.R.E.A.T.H.E. method has become my daily anchor."</p>
            </TestimonialCard>
            
            <TestimonialCard>
              <img src="/images/testimonial2-placeholder.jpg" alt="Testimonial 2" />
              <h3>Sarah M.</h3>
              <p className="role">Healthcare Professional</p>
              <p>"As someone who helps others all day, I needed something for myself. This program taught me how small daily practices can prevent burnout and restore balance."</p>
            </TestimonialCard>
            
            <TestimonialCard>
              <img src="/images/testimonial3-placeholder.jpg" alt="Testimonial 3" />
              <h3>Michael T.</h3>
              <p className="role">Business Executive</p>
              <p>"I was skeptical about the mind-body-spirit approach, but the results speak for themselves. Better focus, more energy, and improved relationships in just two weeks."</p>
            </TestimonialCard>
          </TestimonialsGrid>
        </Section>

        {/* FAQ Section */}
        <Section id="faq" className="dark">
          <SectionTitle>Frequently Asked Questions</SectionTitle>
          
          <FAQContainer>
            <FAQItem>
              <FAQQuestion>
                <h3>How much time does the program require each day?</h3>
                <span>+</span>
              </FAQQuestion>
              <FAQAnswer>
                <p>The core practices take 20-30 minutes daily. Additional optional practices are available if you have more time. The program is designed to be flexible and fit into your schedule.</p>
              </FAQAnswer>
            </FAQItem>
            
            <FAQItem>
              <FAQQuestion>
                <h3>Do I need any special equipment?</h3>
                <span>+</span>
              </FAQQuestion>
              <FAQAnswer>
                <p>No special equipment is required. A yoga mat or comfortable floor space is helpful but not necessary. All practices can be modified to work with what you have available.</p>
              </FAQAnswer>
            </FAQItem>
            
            <FAQItem>
              <FAQQuestion>
                <h3>Is this program religious?</h3>
                <span>+</span>
              </FAQQuestion>
              <FAQAnswer>
                <p>No. While the program includes spiritual elements, it's designed to be compatible with any faith tradition or secular perspective. The focus is on universal principles of wellbeing.</p>
              </FAQAnswer>
            </FAQItem>
            
            <FAQItem>
              <FAQQuestion>
                <h3>What happens after the 14 days?</h3>
                <span>+</span>
              </FAQQuestion>
              <FAQAnswer>
                <p>You'll have the option to continue with our 12-week mentorship program, explore DNA/gut testing for personalized insights, or simply maintain the practices you've learned. The choice is yours.</p>
              </FAQAnswer>
            </FAQItem>
            
            <FAQItem>
              <FAQQuestion>
                <h3>How is this different from other fitness programs?</h3>
                <span>+</span>
              </FAQQuestion>
              <FAQAnswer>
                <p>Most programs focus only on physical training. Harmonized Fitness integrates mind, body, and spirit for complete transformation. We also provide personalized guidance through Dr. U, our AI coach.</p>
              </FAQAnswer>
            </FAQItem>
            
            <FAQItem>
              <FAQQuestion>
                <h3>Is the military discount available for family members?</h3>
                <span>+</span>
              </FAQQuestion>
              <FAQAnswer>
                <p>Yes, the 20% discount is available for active duty, veterans, and their immediate family members. Verification is simple and can be completed during registration.</p>
              </FAQAnswer>
            </FAQItem>
          </FAQContainer>
        </Section>

        {/* Call to Action Section */}
        <Section id="signup">
          <SectionTitle>Begin Your Transformation Today</SectionTitle>
          <p className="section-description">Take the first step toward harmonized fitness</p>
          
          <SignupForm>
            <input type="text" placeholder="Your Name" />
            <input type="email" placeholder="Your Email" />
            <select>
              <option value="">Select Your Plan</option>
              <option value="basic">Basic ($49)</option>
              <option value="premium">Premium ($79)</option>
              <option value="elite">Elite ($129)</option>
            </select>
            <label>
              <input type="checkbox" />
              <span>I qualify for the military discount</span>
            </label>
            <CTAButton type="submit">Start My 14-Day Journey</CTAButton>
          </SignupForm>
          
          <Guarantee>
            <h3>100% Satisfaction Guarantee</h3>
            <p>If you're not completely satisfied within the first 7 days, we'll refund your purchase—no questions asked.</p>
          </Guarantee>
        </Section>
      </main>

      <Footer>
        <FooterGrid>
          <FooterColumn>
            <h3>Harmonized Fitness</h3>
            <p>Transform your mind, body, and spirit with our integrated approach to fitness and wellbeing.</p>
            <SocialLinks>
              <a href="#" aria-label="Facebook">FB</a>
              <a href="#" aria-label="Instagram">IG</a>
              <a href="#" aria-label="Twitter">TW</a>
              <a href="#" aria-label="YouTube">YT</a>
            </SocialLinks>
          </FooterColumn>
          
          <FooterColumn>
            <h3>Quick Links</h3>
            <FooterLinks>
              <li><a href="#about">About</a></li>
              <li><a href="#breathe">B.R.E.A.T.H.E. Code</a></li>
              <li><a href="#prelude">14-Day Prelude</a></li>
              <li><a href="#dru">Dr. U</a></li>
              <li><a href="#pricing">Pricing</a></li>
            </FooterLinks>
          </FooterColumn>
          
          <FooterColumn>
            <h3>Resources</h3>
            <FooterLinks>
              <li><a href="#">Blog</a></li>
              <li><a href="#">Podcast</a></li>
              <li><a href="#">Free Guides</a></li>
              <li><a href="#">Research</a></li>
            </FooterLinks>
          </FooterColumn>
          
          <FooterColumn>
            <h3>Contact</h3>
            <FooterLinks>
              <li><a href="mailto:info@harmonizedfitness.com">info@harmonizedfitness.com</a></li>
              <li><a href="tel:+18005551234">1-800-555-1234</a></li>
              <li><a href="#">Support</a></li>
            </FooterLinks>
          </FooterColumn>
        </FooterGrid>
        
        <FooterBottom>
          <p>&copy; 2025 Harmonized Fitness. All rights reserved.</p>
          <FooterLegal>
            <a href="#">Privacy Policy</a>
            <a href="#">Terms of Service</a>
            <a href="#">Cookie Policy</a>
          </FooterLegal>
        </FooterBottom>
      </Footer>
    </Container>
  );
};

// Styled Components
const Container = styled.div`
  background-color: #2A2A2A;
  color: #FFFFFF;
  font-family: 'Georgia', serif;
`;

const Logo = styled.div`
  font-size: 1.5rem;
  font-weight: bold;
`;

const MenuButton = styled.button`
  display: none;
  flex-direction: column;
  justify-content: space-around;
  width: 2rem;
  height: 2rem;
  background: transparent;
  border: none;
  cursor: pointer;
  padding: 0;
  z-index: 10;
  
  span {
    width: 2rem;
    height: 0.25rem;
    background: #FFFFFF;
    border-radius: 10px;
    transition: all 0.3s linear;
    position: relative;
    transform-origin: 1px;
  }
  
  @media (max-width: 768px) {
    display: flex;
  }
`;

const NavLinks = styled.ul`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  list-style: none;
  
  li {
    margin: 0 1rem;
  }
  
  a {
    color: #FFFFFF;
    text-decoration: none;
    font-size: 1rem;
    
    &.cta-button {
      background-color: #D35400;
      padding: 0.5rem 1rem;
      border-radius: 4px;
    }
  }
  
  @media (max-width: 768px) {
    flex-direction: column;
    background-color: #2A2A2A;
    position: fixed;
    transform: ${({ isOpen }) => isOpen ? 'translateX(0)' : 'translateX(100%)'};
    top: 0;
    right: 0;
    height: 100vh;
    width: 300px;
    padding-top: 3.5rem;
    transition: transform 0.3s ease-in-out;
    z-index: 9;
    
    li {
      margin: 1rem 0;
    }
  }
`;

const HeroSection = styled.section`
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background-image: url('/images/hero-bg-placeholder.jpg');
  background-size: cover;
  background-position: center;
  position: relative;
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.6);
  }
`;

const HeroContent = styled.div`
  text-align: center;
  max-width: 800px;
  padding: 0 2rem;
  position: relative;
  z-index: 1;
  
  h1 {
    font-size: 3.5rem;
    margin-bottom: 1rem;
  }
  
  p {
    font-size: 1.25rem;
    margin-bottom: 2rem;
  }
`;

const CTAButton = styled.a`
  display: inline-block;
  background-color: #D35400;
  color: #FFFFFF;
  padding: 1rem 2rem;
  border-radius: 4px;
  font-size: 1.25rem;
  text-decoration: none;
  transition: background-color 0.3s ease;
  
  &:hover {
    background-color: #E67E22;
  }
`;

const Section = styled.section`
  padding: 5rem 2rem;
  
  &.dark {
    background-color: #222222;
  }
  
  .section-description {
    text-align: center;
    font-size: 1.25rem;
    max-width: 800px;
    margin: 0 auto 3rem;
  }
`;

const SectionTitle = styled.h2`
  text-align: center;
  font-size: 2.5rem;
  margin-bottom: 1rem;
`;

const TwoColumn = styled.div`
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  max-width: 1200px;
  margin: 0 auto;
  
  @media (max-width: 768px) {
    flex-direction: column;
  }
`;

const Column = styled.div`
  flex: 1;
  min-width: 300px;
  padding: 1rem;
  
  h3 {
    font-size: 1.5rem;
    margin-bottom: 1rem;
  }
  
  p {
    margin-bottom: 1.5rem;
    line-height: 1.6;
  }
  
  img {
    max-width: 100%;
    border-radius: 8px;
  }
`;

const BreatheGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 2rem;
  max-width: 1200px;
  margin: 0 auto;
`;

const BreatheItem = styled.div`
  background-color: #333333;
  padding: 2rem;
  border-radius: 8px;
  text-align: center;
  
  h3 {
    font-size: 1.5rem;
    margin-bottom: 1rem;
    
    span {
      color: ${props => props.color};
      font-weight: bold;
    }
  }
  
  p {
    line-height: 1.6;
  }
`;

const PreludeGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 2rem;
  max-width: 1200px;
  margin: 0 auto 3rem;
`;

const PreludeItem = styled.div`
  background-color: #333333;
  padding: 2rem;
  border-radius: 8px;
  
  h3 {
    font-size: 1.5rem;
    margin-bottom: 1rem;
    color: #D35400;
  }
  
  p {
    line-height: 1.6;
  }
`;

const DaysList = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1rem;
  max-width: 1200px;
  margin: 0 auto;
`;

const DayItem = styled.div`
  background-color: #333333;
  padding: 1rem;
  border-radius: 4px;
  text-align: center;
`;

const PricingGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 2rem;
  max-width: 1200px;
  margin: 0 auto 3rem;
`;

const PricingCard = styled.div`
  background-color: #333333;
  padding: 2rem;
  border-radius: 8px;
  text-align: center;
  transition: transform 0.3s ease;
  
  ${props => props.featured && `
    transform: scale(1.05);
    border: 2px solid #D35400;
  `}
  
  &:hover {
    transform: translateY(-10px);
  }
  
  h3 {
    font-size: 1.5rem;
    margin-bottom: 1rem;
  }
  
  ul {
    list-style: none;
    padding: 0;
    margin: 2rem 0;
    text-align: left;
    
    li {
      margin-bottom: 0.5rem;
      padding-left: 1.5rem;
      position: relative;
      
      &::before {
        content: '✓';
        position: absolute;
        left: 0;
        color: #D35400;
      }
    }
  }
`;

const PriceTag = styled.div`
  font-size: 2.5rem;
  font-weight: bold;
  color: #D35400;
  margin: 1rem 0;
`;

const MilitaryDiscount = styled.div`
  text-align: center;
  max-width: 600px;
  margin: 0 auto;
  padding: 2rem;
  background-color: #333333;
  border-radius: 8px;
  
  h3 {
    font-size: 1.5rem;
    margin-bottom: 1rem;
    color: #D35400;
  }
`;

const TestimonialsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 2rem;
  max-width: 1200px;
  margin: 0 auto;
`;

const TestimonialCard = styled.div`
  background-color: #333333;
  padding: 2rem;
  border-radius: 8px;
  text-align: center;
  
  img {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    object-fit: cover;
    margin-bottom: 1rem;
  }
  
  h3 {
    font-size: 1.25rem;
    margin-bottom: 0.5rem;
  }
  
  .role {
    color: #D35400;
    margin-bottom: 1rem;
  }
  
  p {
    font-style: italic;
    line-height: 1.6;
  }
`;

const FAQContainer = styled.div`
  max-width: 800px;
  margin: 0 auto;
`;

const FAQItem = styled.div`
  margin-bottom: 1rem;
  border-radius: 4px;
  overflow: hidden;
`;

const FAQQuestion = styled.div`
  background-color: #333333;
  padding: 1rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  cursor: pointer;
  
  h3 {
    margin: 0;
    font-size: 1.25rem;
  }
  
  span {
    font-size: 1.5rem;
  }
`;

const FAQAnswer = styled.div`
  background-color: #444444;
  padding: 1rem;
  
  p {
    margin: 0;
    line-height: 1.6;
  }
`;

const SignupForm = styled.form`
  max-width: 600px;
  margin: 0 auto;
  display: flex;
  flex-direction: column;
  gap: 1rem;
  
  input, select {
    padding: 1rem;
    border-radius: 4px;
    border: none;
    background-color: #333333;
    color: #FFFFFF;
  }
  
  label {
    display: flex;
    align-items: center;
    gap: 0.5rem;
  }
`;

const Guarantee = styled.div`
  text-align: center;
  max-width: 600px;
  margin: 2rem auto 0;
  
  h3 {
    font-size: 1.25rem;
    margin-bottom: 0.5rem;
    color: #D35400;
  }
`;

const Footer = styled.footer`
  background-color: #222222;
  padding: 5rem 2rem 2rem;
`;

const FooterGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 2rem;
  max-width: 1200px;
  margin: 0 auto 3rem;
`;

const FooterColumn = styled.div`
  h3 {
    font-size: 1.25rem;
    margin-bottom: 1rem;
    color: #D35400;
  }
  
  p {
    margin-bottom: 1rem;
    line-height: 1.6;
  }
`;

const SocialLinks = styled.div`
  display: flex;
  gap: 1rem;
  
  a {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 40px;
    height: 40px;
    background-color: #333333;
    border-radius: 50%;
    color: #FFFFFF;
    text-decoration: none;
  }
`;

const FooterLinks = styled.ul`
  list-style: none;
  padding: 0;
  
  li {
    margin-bottom: 0.5rem;
  }
  
  a {
    color: #FFFFFF;
    text-decoration: none;
    
    &:hover {
      color: #D35400;
    }
  }
`;

const FooterBottom = styled.div`
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  align-items: center;
  max-width: 1200px;
  margin: 0 auto;
  padding-top: 2rem;
  border-top: 1px solid #333333;
  
  @media (max-width: 768px) {
    flex-direction: column;
    gap: 1rem;
  }
`;

const FooterLegal = styled.div`
  display: flex;
  gap: 1rem;
  
  a {
    color: #FFFFFF;
    text-decoration: none;
    
    &:hover {
      color: #D35400;
    }
  }
`;

export default HomePage;
