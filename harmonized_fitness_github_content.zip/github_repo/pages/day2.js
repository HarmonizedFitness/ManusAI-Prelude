import { useState } from 'react';
import Head from 'next/head';
import DayLayout from '../components/DayLayout';
import styled from 'styled-components';

const Day2 = () => {
  const [activeTab, setActiveTab] = useState('morning');

  return (
    <>
      <Head>
        <title>Day 2: Breath & Presence | Harmonized Fitness</title>
        <meta name="description" content="Explore the power of breath as a tool for presence, introducing the 'B' of the B.R.E.A.T.H.E. Code - Be the Change." />
      </Head>

      <DayLayout day={2} title="Breath & Presence">
        {activeTab === 'morning' && (
          <MorningSection>
            <h2>Morning Ritual</h2>
            <p>Welcome to Day 2! Today we focus on breath awareness—the most accessible tool for presence and the foundation of all mind-body practices. Your breath is always with you, making it the perfect anchor for presence.</p>
            
            <h3>Intention Setting (3 minutes)</h3>
            <p>Find your quiet space and sit comfortably. Take three deep breaths to center yourself. Today, set an intention related to presence: "My intention is to be fully present in each moment today."</p>
            
            <h3>Three-Part Breath (7 minutes)</h3>
            <p>The three-part breath activates your full breathing capacity and calms your nervous system. Practice as follows:</p>
            <ol>
              <li>Place one hand on your belly and one on your chest</li>
              <li>Inhale slowly through your nose, filling first your lower belly (feel it expand)</li>
              <li>Continue the same inhale, expanding your ribcage outward</li>
              <li>Complete the inhale by letting your upper chest rise</li>
              <li>Exhale slowly in reverse: chest, ribcage, belly</li>
              <li>Repeat for 7 minutes, finding a natural rhythm</li>
            </ol>
            
            <h3>B.R.E.A.T.H.E. Code: "B" - Be the Change (5 minutes)</h3>
            <BreatheElement color="#FF0000">
              <h4>B: Be the Change</h4>
              <p>The first element of the B.R.E.A.T.H.E. Code invites you to embody the transformation you want to see. Rather than waiting for external circumstances to change, you become the agent of change through your presence and awareness.</p>
              <p>Reflect on this question: "How can I embody the change I wish to see in my health and wellbeing today?"</p>
              <p>Write your answer in your journal, being as specific as possible about one small way you can "be the change" today.</p>
            </BreatheElement>
            
            <Quote>"Breath is the bridge which connects life to consciousness, which unites your body to your thoughts." - Thich Nhat Hanh</Quote>
          </MorningSection>
        )}

        {activeTab === 'physical' && (
          <PhysicalSection>
            <h2>Physical Practice</h2>
            <p>Today's physical practice integrates breath awareness with movement, helping you develop the mind-body connection that forms the foundation of harmonized fitness.</p>
            
            <h3>Breath-Centered Movement (20 minutes)</h3>
            <p>This practice coordinates simple movements with your breath, enhancing body awareness and presence.</p>
            
            <h4>1. Warm-up: Breath-Synchronized Arm Raises (3 minutes)</h4>
            <p>Stand with feet hip-width apart, arms at your sides:</p>
            <ul>
              <li>Inhale: Raise your arms out to the sides and up overhead</li>
              <li>Exhale: Lower your arms back down to your sides</li>
              <li>Repeat for 3 minutes, synchronizing movement precisely with breath</li>
            </ul>
            <p><strong>Things to think about:</strong> Can you make the movement last exactly as long as your breath? Notice how slowing down the movement naturally deepens your breath.</p>
            
            <h4>2. Core Breath Awareness (5 minutes)</h4>
            <MovementItem>
              <h5>360° Breathing</h5>
              <p>Lie on your back with knees bent, feet flat on the floor:</p>
              <ul>
                <li>Place your hands on your lower ribs</li>
                <li>Inhale: Feel your ribs expand in all directions (front, sides, and back)</li>
                <li>Exhale: Feel your ribs gently contract</li>
                <li>Continue for 2 minutes, focusing on the sensation</li>
              </ul>
              <p><strong>Things to think about:</strong> Can you feel your breath in your back body? Are you allowing your breath to be natural rather than forced?</p>
            </MovementItem>
            
            <MovementItem>
              <h5>Breath with Gentle Core Engagement</h5>
              <p>Remain on your back with knees bent:</p>
              <ul>
                <li>Inhale: Allow your belly to expand</li>
                <li>Exhale: Gently draw your navel toward your spine while maintaining a natural breath</li>
                <li>Continue for 3 minutes, keeping the engagement subtle (about 20% effort)</li>
              </ul>
              <p><strong>Things to think about:</strong> Can you maintain the gentle engagement without creating tension? Is your breath still flowing naturally?</p>
            </MovementItem>
            
            <h4>3. Breath-Movement Flow (12 minutes)</h4>
            <p>Perform each movement for 2 minutes, focusing on the breath-movement coordination:</p>
            
            <MovementItem>
              <h5>Cat-Cow Breath</h5>
              <p>Begin on hands and knees, wrists under shoulders, knees under hips:</p>
              <ul>
                <li>Inhale: Drop your belly, lift your chest and tailbone (cow)</li>
                <li>Exhale: Round your spine, tuck your tailbone, draw navel to spine (cat)</li>
                <li>Move slowly, matching movement precisely to breath</li>
              </ul>
              <p><strong>Things to think about:</strong> Can you initiate the movement from your breath rather than muscular effort? How does your spine feel as it articulates?</p>
            </MovementItem>
            
            <MovementItem>
              <h5>Standing Side Bend Breath</h5>
              <p>Stand with feet hip-width apart:</p>
              <ul>
                <li>Inhale: Raise your right arm overhead</li>
                <li>Exhale: Side bend to the left, sliding your left hand down your leg</li>
                <li>Inhale: Return to center</li>
                <li>Exhale: Lower your right arm</li>
                <li>Repeat on the other side</li>
                <li>Continue alternating sides, moving with your breath</li>
              </ul>
              <p><strong>Things to think about:</strong> Can you feel the expansion of your ribs on the stretched side? Are you keeping both feet grounded?</p>
            </MovementItem>
            
            <MovementItem>
              <h5>Standing Forward Fold with Breath</h5>
              <p>Stand with feet hip-width apart:</p>
              <ul>
                <li>Inhale: Raise arms overhead</li>
                <li>Exhale: Hinge at hips to fold forward, bringing hands toward floor (bend knees as needed)</li>
                <li>Inhale: Lift halfway up, extending spine forward</li>
                <li>Exhale: Fold forward again</li>
                <li>Inhale: Rise all the way up, bringing arms overhead</li>
                <li>Exhale: Lower arms to sides</li>
                <li>Continue flowing with your breath</li>
              </ul>
              <p><strong>Things to think about:</strong> Can you initiate the movement from your hips rather than rounding your back? How does your breath change as you fold forward?</p>
            </MovementItem>
            
            <Quote>"When you own your breath, nobody can steal your peace." - Unknown</Quote>
          </PhysicalSection>
        )}

        {activeTab === 'integration' && (
          <IntegrationSection>
            <h2>Integration Practice</h2>
            <p>This afternoon practice helps you integrate breath awareness into your daily activities, reinforcing the "B" (Be the Change) element of the B.R.E.A.T.H.E. Code.</p>
            
            <h3>Breath Awareness Triggers (Throughout the Day)</h3>
            <p>Remember the awareness trigger you selected yesterday? Today, when that trigger occurs:</p>
            <ol>
              <li>Pause and take three conscious breaths</li>
              <li>For each breath, mentally repeat: "I am the change"</li>
              <li>Notice how this brief pause affects your state</li>
            </ol>
            <p>This practice reinforces the connection between breath, awareness, and embodying change.</p>
            
            <h3>Box Breathing for Focus (5 minutes)</h3>
            <p>Box breathing is a powerful technique for enhancing focus and presence. Practice it when you need to center yourself:</p>
            <BoxBreathingVisual>
              <div className="box">
                <div className="step">Inhale for 4 counts</div>
                <div className="step">Hold for 4 counts</div>
                <div className="step">Exhale for 4 counts</div>
                <div className="step">Hold for 4 counts</div>
              </div>
            </BoxBreathingVisual>
            <p>Repeat this pattern for 5 minutes, visualizing tracing a square with your breath.</p>
            
            <h3>Journaling Prompt (5 minutes)</h3>
            <p>In your journal, reflect on the following questions:</p>
            <ul>
              <li>How does your breath change in different situations (stress, relaxation, focus, etc.)?</li>
              <li>What did you notice about the connection between your breath and movement during today's physical practice?</li>
              <li>In what specific way are you "being the change" today?</li>
              <li>How might regular breath awareness practice impact your daily life?</li>
            </ul>
            
            <Quote>"Breathing in, I calm body and mind. Breathing out, I smile." - Thich Nhat Hanh</Quote>
          </IntegrationSection>
        )}

        {activeTab === 'evening' && (
          <EveningSection>
            <h2>Evening Check-in</h2>
            <p>This evening practice helps you integrate today's focus on breath and presence, preparing you for restful sleep and tomorrow's journey.</p>
            
            <h3>Day 2 Reflection (5 minutes)</h3>
            <p>Find your quiet space and take three deep breaths to center yourself. Reflect on the following questions:</p>
            <ul>
              <li>How often were you aware of your breath today?</li>
              <li>Did you notice any patterns in your breathing during different activities?</li>
              <li>How did the breath-centered movement practice affect your body and mind?</li>
              <li>In what moments did you successfully "be the change" today?</li>
              <li>What challenges did you face in maintaining breath awareness?</li>
            </ul>
            
            <h3>Gratitude Practice (3 minutes)</h3>
            <p>Identify three specific things you're grateful for today. For each item, take a full breath cycle (inhale and exhale) to fully experience the feeling of gratitude in your body.</p>
            
            <h3>Tomorrow's Micro-Habit: Breath Before Reactions (2 minutes)</h3>
            <p>Set an intention to take one conscious breath before responding in any challenging situation tomorrow. This creates space between stimulus and response, allowing you to choose your reaction rather than being controlled by it.</p>
            <p>Mentally rehearse this practice now by imagining a potentially challenging situation and visualizing yourself taking a breath before responding.</p>
            
            <h3>Extended Exhale for Sleep (5 minutes)</h3>
            <p>This breathing pattern activates your parasympathetic nervous system, preparing your body for deep rest:</p>
            <ol>
              <li>Lie comfortably in bed</li>
              <li>Breathe in through your nose for a count of 4</li>
              <li>Breathe out through your nose for a count of 6</li>
              <li>Continue for 5 minutes, gradually extending the exhale if comfortable</li>
              <li>Allow your natural breathing pattern to return as you drift toward sleep</li>
            </ol>
            
            <Quote>"Each breath is a gift of life, a chance to begin again." - Unknown</Quote>
          </EveningSection>
        )}

        {activeTab === 'resources' && (
          <ResourcesSection>
            <h2>Resources</h2>
            <p>These resources will deepen your understanding of breath practices and support your Day 2 experience.</p>
            
            <h3>Recommended Reading</h3>
            <ResourceList>
              <ResourceItem>
                <h4>"Breath: The New Science of a Lost Art" by James Nestor</h4>
                <p>Explores the science and practice of optimal breathing for health and wellbeing.</p>
                <a href="https://www.mrjamesnestor.com/breath" target="_blank" rel="noopener noreferrer">Learn More</a>
              </ResourceItem>
              
              <ResourceItem>
                <h4>"The Power of Now" by Eckhart Tolle</h4>
                <p>A guide to living in the present moment through breath and awareness.</p>
                <a href="https://www.eckharttolle.com/books/now/" target="_blank" rel="noopener noreferrer">Learn More</a>
              </ResourceItem>
              
              <ResourceItem>
                <h4>"Wherever You Go, There You Are" by Jon Kabat-Zinn</h4>
                <p>Practical guidance on mindfulness and breath awareness in daily life.</p>
                <a href="https://www.mindfulnesscds.com/pages/books-by-jon-kabat-zinn" target="_blank" rel="noopener noreferrer">Learn More</a>
              </ResourceItem>
            </ResourceList>
            
            <h3>Video Resources</h3>
            <ResourceList>
              <ResourceItem>
                <h4>"Three-Part Breath Tutorial" - Yoga Journal</h4>
                <p>Visual instruction for the three-part breath practice.</p>
                <a href="https://www.youtube.com/watch?v=FgKMd2TtQZY" target="_blank" rel="noopener noreferrer">Watch Video</a>
              </ResourceItem>
            </ResourceList>
            
            <h3>Scientific Research</h3>
            <ResourceList>
              <ResourceItem>
                <h4>"The Science of Breathing" - Frontiers in Psychology</h4>
                <p>Research on how breathing affects physiology and psychology.</p>
                <a href="https://www.frontiersin.org/articles/10.3389/fpsyg.2018.01924/full" target="_blank" rel="noopener noreferrer">View Research</a>
              </ResourceItem>
            </ResourceList>
            
            <h3>Downloadable Resources</h3>
            <ResourceList>
              <ResourceItem>
                <h4>Day 2 Practice Worksheet</h4>
                <p>Printable worksheet with today's practices and reflection questions.</p>
                <a href="/pdfs/day2_practice_worksheet.pdf" target="_blank" rel="noopener noreferrer">Download PDF</a>
              </ResourceItem>
              
              <ResourceItem>
                <h4>Breath Practices Guide</h4>
                <p>Comprehensive guide to various breathing techniques and their benefits.</p>
                <a href="/pdfs/breath_practices_guide.pdf" target="_blank" rel="noopener noreferrer">Download PDF</a>
              </ResourceItem>
              
              <ResourceItem>
                <h4>B.R.E.A.T.H.E. Code Reference Guide</h4>
                <p>Complete guide to both versions of the B.R.E.A.T.H.E. Code with practical applications.</p>
                <a href="/pdfs/breathe_code_reference_guide.pdf" target="_blank" rel="noopener noreferrer">Download PDF</a>
              </ResourceItem>
            </ResourceList>
            
            <h3>Apps & Digital Tools</h3>
            <ResourceList>
              <ResourceItem>
                <h4>Breathwrk</h4>
                <p>Guided breathing exercises for various purposes (stress, energy, focus, sleep).</p>
                <a href="https://www.breathwrk.com/" target="_blank" rel="noopener noreferrer">Visit Website</a>
              </ResourceItem>
              
              <ResourceItem>
                <h4>Calm</h4>
                <p>Features breathing exercises, meditation, and sleep content.</p>
                <a href="https://www.calm.com/" target="_blank" rel="noopener noreferrer">Visit Website</a>
              </ResourceItem>
            </ResourceList>
          </ResourcesSection>
        )}
      </DayLayout>
    </>
  );
};

// Styled Components
const MorningSection = styled.div`
  h2 {
    color: #D35400;
    margin-bottom: 1.5rem;
  }
  
  h3 {
    margin-top: 2rem;
    margin-bottom: 1rem;
  }
  
  p {
    line-height: 1.6;
    margin-bottom: 1rem;
  }
  
  ol {
    margin-bottom: 1.5rem;
    padding-left: 1.5rem;
    
    li {
      margin-bottom: 0.5rem;
    }
  }
`;

const BreatheElement = styled.div`
  background-color: #2A2A2A;
  padding: 1.5rem;
  border-radius: 8px;
  margin: 2rem 0;
  border-left: 5px solid ${props => props.color};
  
  h4 {
    color: ${props => props.color};
    margin-bottom: 1rem;
  }
  
  p {
    margin-bottom: 1rem;
  }
`;

const PhysicalSection = styled.div`
  h2 {
    color: #D35400;
    margin-bottom: 1.5rem;
  }
  
  h3, h4 {
    margin-top: 2rem;
    margin-bottom: 1rem;
  }
  
  p {
    line-height: 1.6;
    margin-bottom: 1rem;
  }
  
  ul {
    margin-bottom: 1.5rem;
    padding-left: 1.5rem;
    
    li {
      margin-bottom: 0.5rem;
    }
  }
`;

const MovementItem = styled.div`
  background-color: #2A2A2A;
  padding: 1.5rem;
  border-radius: 8px;
  margin-bottom: 1.5rem;
  
  h5 {
    color: #D35400;
    margin-bottom: 1rem;
  }
  
  p {
    margin-bottom: 0.5rem;
  }
  
  ul {
    margin-bottom: 1rem;
  }
`;

const IntegrationSection = styled.div`
  h2 {
    color: #D35400;
    margin-bottom: 1.5rem;
  }
  
  h3 {
    margin-top: 2rem;
    margin-bottom: 1rem;
  }
  
  p {
    line-height: 1.6;
    margin-bottom: 1rem;
  }
  
  ul, ol {
    margin-bottom: 1.5rem;
    padding-left: 1.5rem;
    
    li {
      margin-bottom: 0.5rem;
    }
  }
`;

const BoxBreathingVisual = styled.div`
  margin: 2rem 0;
  
  .box {
    display: grid;
    grid-template-columns: 1fr 1fr;
    grid-template-rows: 1fr 1fr;
    gap: 2px;
    width: 300px;
    height: 300px;
    margin: 0 auto;
  }
  
  .step {
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: #2A2A2A;
    padding: 1rem;
    text-align: center;
    font-size: 0.9rem;
  }
`;

const EveningSection = styled.div`
  h2 {
    color: #D35400;
    margin-bottom: 1.5rem;
  }
  
  h3 {
    margin-top: 2rem;
    margin-bottom: 1rem;
  }
  
  p {
    line-height: 1.6;
    margin-bottom: 1rem;
  }
  
  ul, ol {
    margin-bottom: 1.5rem;
    padding-left: 1.5rem;
    
    li {
      margin-bottom: 0.5rem;
    }
  }
`;

const ResourcesSection = styled.div`
  h2 {
    color: #D35400;
    margin-bottom: 1.5rem;
  }
  
  h3 {
    margin-top: 2rem;
    margin-bottom: 1rem;
  }
  
  p {
    line-height: 1.6;
    margin-bottom: 1rem;
  }
`;

const ResourceList = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 1.5rem;
  margin-bottom: 2rem;
`;

const ResourceItem = styled.div`
  background-color: #2A2A2A;
  padding: 1.5rem;
  border-radius: 8px;
  
  h4 {
    color: #D35400;
    margin-bottom: 0.5rem;
  }
  
  p {
    margin-bottom: 1rem;
  }
  
  a {
    color: #FFFFFF;
    background-color: #D35400;
    padding: 0.5rem 1rem;
    border-radius: 4px;
    text-decoration: none;
    display: inline-block;
    
    &:hover {
      background-color: #E67E22;
    }
  }
`;

const Quote = styled.blockquote`
  font-style: italic;
  border-left: 3px solid #D35400;
  padding-left: 1rem;
  margin: 2rem 0;
  color: #E67E22;
`;

export default Day2;
